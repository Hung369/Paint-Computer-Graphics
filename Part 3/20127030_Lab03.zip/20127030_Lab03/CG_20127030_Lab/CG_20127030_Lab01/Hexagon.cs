﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Hexagon : Shape
    {
        //AB là đáy trên, DE là đáy dưới, F là điểm trái nhất
        Point A, B, C, D, E, F;
        protected string fill_mode;
        public Hexagon(List<Point> vertices, Point Start, Point End, float thick, Color color, Color color_fill, bool isFill, string fill_mode) 
            : base(vertices, Start, End, thick, color, color_fill, isFill)
        {
            // Khoảng cách khối theo Oy
            int dy = End.Y - Start.Y;
            // Khoảng cách khối theo Ox
            int dx = End.X - Start.X;

            // tính cạnh của ngũ giác đều
            double a = Math.Abs(dx) / 2; // bán kính đường tròn ngoại tiếp và độ dài cạnh
            double b = a / 2;
            double h = a * Math.Sqrt(3);
            double h1 = h / 2; // bán kính đường tròn nội tiếp của lục giác đều

            if (dy < 0) // Nếu End nằm trên Start
            {
                D.Y = Start.Y;
                E.Y = Start.Y;
            }
            else // End bằm dưới Start hay End.y = Start.y
            {
                D.Y = End.Y;
                E.Y = End.Y;
            }

            F.Y = E.Y - (int)h1;
            C.Y = E.Y - (int)h1;
            A.Y = E.Y - (int)h;
            B.Y = E.Y - (int)h;

            if (dx > 0) //nếu End nằm bên phải Start
            {
                F.X = Start.X;
                C.X = End.X;
            }
            else //nếu End nằm bên trái Start hay End.X = Start.X
            {
                F.X = End.X;
                C.X = Start.X;
            }
            E.X = F.X + (int)Math.Round(b);
            D.X = C.X - (int)Math.Round(b);
            A.X = E.X;
            B.X = D.X;

            this.vertices = new List<Point>();
            this.vertices.Add(A);
            this.vertices.Add(B);
            this.vertices.Add(C);
            this.vertices.Add(D);
            this.vertices.Add(E);
            this.vertices.Add(F);
            setControlPoints(); // thiết lập các điểm điều khiển

            this.fill_mode = fill_mode;
        }
        public override void showShape(OpenGL gl)
        {
            FillShape(gl);
            if (List_Points.Count() != 0)
            {
                List_Points.Clear();
            }
            for (int i = 0; i < 5; i++)
            {
                DrawLine(vertices[i], vertices[i + 1], gl);
            }
            DrawLine(vertices[5], vertices[0], gl);
        }

        public override void editShape(List<Point> vertices, List<Point> points, List<Point> controlPoints, float thick, Color color, Color color_fill, bool isFill)
        {
            base.editShape(vertices, points, controlPoints, thick, color, color_fill, isFill);
            this.vertices = new List<Point>(vertices);

        }
        public override void ShowEditShape(OpenGL gl)
        {
            showShape(gl);
            DrawSetControl(gl);
        }
        public override void FillShape(OpenGL gl)
        {
            if (isFill)
            {
                if (fill_mode == "flood")
                {
                    // lấy điểm trên đoạn thẳng CF
                    var cen = new Point((C.X + F.X) / 2, gl.RenderContextProvider.Height - (C.Y + F.Y) / 2);
                    this.fill.Floodfill(cen.X, cen.Y, FillColor, color, gl);
                }
                if (fill_mode == "scan")
                    fill.ScanFill(vertices, FillColor, gl);
            }
        }


        public override void setControlPoints()
        {
            // Lấy tập điểm kiểm soát.
            Point topLeft, topMid, topRight, midLeft, midRight, bottomLeft, bottomMid, bottomRight;
            topLeft = new Point(F.X, A.Y);
            topMid = new Point((F.X + C.X) / 2, A.Y);
            topRight = new Point(C.X, A.Y);

            midLeft = new Point(F.X, F.Y);
            midRight = new Point(C.X, C.Y);

            bottomLeft = new Point(F.X, E.Y);
            bottomMid = new Point((F.X + C.X) / 2, E.Y);
            bottomRight = new Point(C.X, E.Y);

            Ctrl_Points = new List<Point>();
            Ctrl_Points.Add(topLeft);
            Ctrl_Points.Add(topMid);
            Ctrl_Points.Add(topRight);
            Ctrl_Points.Add(midRight);
            Ctrl_Points.Add(bottomRight);
            Ctrl_Points.Add(bottomMid);
            Ctrl_Points.Add(bottomLeft);
            Ctrl_Points.Add(midLeft);
        }

        public override Point getCenter()
        {
            // tâm = trung điểm đường chéo
            Point center_hex = new Point((vertices[0].X + vertices[3].X) / 2, (vertices[0].Y + vertices[3].Y) / 2);
            return center_hex;
        }


        public override int getShapeType()
        {
            int HexaType = 6; // 6: hexagon
            return HexaType;
        }
    }
}
