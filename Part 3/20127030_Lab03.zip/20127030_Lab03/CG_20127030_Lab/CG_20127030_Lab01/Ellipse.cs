﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Ellipse : Shape
    {
        //tâm elip là pStart và pEnd
        int Rx, Ry; // bán kính trục x, trục y
        protected string fill_mode;
        public Ellipse(List<Point> vertices, Point Start, Point End, float thick, Color color, Color color_fill, bool isFill, string fill_mode) 
            : base(vertices, Start, End, thick, color, color_fill, isFill)
        {
            this.vertices = new List<Point>();
            this.vertices.Add(pStart);
            this.vertices.Add(pEnd);
                        
            calculateListPoints(); //Tính toán các điểm trên elip và thêm vào List_Points

            setControlPoints(); //thiết lập các điểm điều khiển

            this.fill_mode = fill_mode;
        }

        public override void calculateListPoints()
        {
            //Rx, Ry
            Rx = Math.Abs(vertices[1].X - vertices[0].X);
            Ry = Math.Abs(vertices[1].Y - vertices[0].Y);

            // tập hợp điểm trên đường elip
            if (List_Points.Count() != 0)
            {
                List_Points.Clear();
            }
            Point CenterPoint = new Point();
            CenterPoint.Y = vertices[0].Y;
            CenterPoint.X = vertices[0].X;

            // điểm đầu tiên
            Point point = new Point(0, Ry);
            // thêm 4 điểm nằm trên trục vào list

            Point point1 = new Point(); // điểm 1(0,Ry)
            point1.X = CenterPoint.X;
            point1.Y = Ry + CenterPoint.Y;
            List_Points.Add(point1);
            
            point1.Y = -Ry + CenterPoint.Y; // điểm 3(0,-Ry)
            List_Points.Add(point1);
            
            point1.X = Rx + CenterPoint.X; // điểm 2(Rx,0)
            point1.Y = CenterPoint.Y;
            List_Points.Add(point1);

            point1.X = -Rx + CenterPoint.X; // điểm 4 K(-Rx,0)
            List_Points.Add(point1);

            
            int R2y = Ry * Ry; // Ry^2
            
            int R2x = Rx * Rx; // Rx^2
           
            int p = R2y - R2x * Ry - R2x / 4; // p0

            // vẽ trên vùng 1
            while (R2y * point.X < R2x * point.Y)
            {
                if (p < 0)
                {
                    point.X += 1;
                    p += 2 * R2y * point.X + R2y;
                }
                else
                {
                    point.X += 1;
                    point.Y -= 1;
                    p += 2 * R2y * point.X - 2 * R2x * point.Y + R2y;
                }

                // lấy đối xứng và tịnh tiến

                Point vertex = new Point(); // điểm (x,y)
                vertex.X = point.X + CenterPoint.X;
                vertex.Y = point.Y + CenterPoint.Y;
                List_Points.Add(vertex);
                
                Point vertex1 = new Point(); // điểm B(-x,y)
                vertex1.X = -point.X + CenterPoint.X;
                vertex1.Y = point.Y + CenterPoint.Y;
                List_Points.Add(vertex1);
                
                Point vertex2 = new Point(); // điểm C(-x,-y)
                vertex2.X = -point.X + CenterPoint.X;
                vertex2.Y = -point.Y + CenterPoint.Y;
                List_Points.Add(vertex2);
                
                Point vertex3 = new Point(); // điểm D(x,-y)
                vertex3.X = point.X + CenterPoint.X;
                vertex3.Y = -point.Y + CenterPoint.Y;
                List_Points.Add(vertex3);
            }

            // vẽ trên vùng 2
            p = R2y * (point.X + 1 / 2) * (point.X + 1 / 2) + R2x * (point.Y - 1) * (point.Y - 1) - R2x * R2y;
            while (point.Y != 0)
            {
                if (p > 0)
                {
                    point.Y -= 1;
                    p += -2 * R2x * point.Y + R2x;
                }
                else
                {
                    point.Y -= 1;
                    point.X += 1;
                    p += 2 * R2y * point.X - 2 * R2x * point.Y + R2x;
                }

                //lấy đối xứng và tịnh tiến

                Point diem = new Point(); // điểm (x,y)
                diem.X = point.X + CenterPoint.X;
                diem.Y = point.Y + CenterPoint.Y;
                List_Points.Add(diem);

                Point diem1 = new Point(); // điểm (-x,y)
                diem1.X = -point.X + CenterPoint.X;
                diem1.Y = point.Y + CenterPoint.Y;
                List_Points.Add(diem1);

                Point diem2 = new Point(); // điểm (-x,-y)
                diem2.X = -point.X + CenterPoint.X;
                diem2.Y = -point.Y + CenterPoint.Y;
                List_Points.Add(diem2);

                Point diem3 = new Point(); // điểm (x,-y)
                diem3.X = point.X + CenterPoint.X;
                diem3.Y = -point.Y + CenterPoint.Y;
                List_Points.Add(diem3);
            }
        }

        public override void showShape(OpenGL gl)
        {
            //tô màu
            FillShape(gl);

            //vẽ elip với tập hợp điểm
            DrawListPoint(List_Points, gl);
        }

        public override void editShape(List<Point> vertices, List<Point> points, List<Point> controlPoints, float thick, Color color, Color color_fill, bool isFill)
        {
            base.editShape(vertices, points, controlPoints, thick, color, color_fill, isFill);
            List_Points = new List<Point>(points);
        }

        public override void ShowEditShape(OpenGL gl)
        {
            showShape(gl);
            DrawSetControl(gl);
        }

        public override void FillShape(OpenGL gl)
        {
            if (isFill)
            {
                if (fill_mode == "flood")
                {
                    // lấy điểm là tâm đường ellipse
                    var cen = new Point(pStart.X, pStart.Y);
                    this.fill.Floodfill(cen.X, cen.Y, FillColor, color, gl);
                }
                else
                {
                    int y_min = int.MaxValue, y_max = int.MinValue;
                    int n = List_Points.Count();
                    for (int i = 0; i < n; i++)
                    {
                        int y_curr = List_Points[i].Y;
                        if (y_curr > y_max)
                        {
                            y_max = y_curr;
                        }
                        if (y_curr < y_min)
                        {
                            y_min = y_curr;
                        }
                    }
                    Point A, B;
                    for (int y = y_min + 1; y < y_max; y++)
                    {
                        A = List_Points.Find(c => c.Y == y);
                        B = List_Points.Find(c => c.Y == y && c.X != A.X);
                        if (A.IsEmpty || B.IsEmpty)
                        {
                            continue;
                        }
                        gl.Color(FillColor.R / 255.0, FillColor.G / 255.0, FillColor.B / 255.0);
                        gl.Begin(OpenGL.GL_LINES);
                        gl.Vertex(A.X, gl.RenderContextProvider.Height - A.Y);
                        gl.Vertex(B.X, gl.RenderContextProvider.Height - B.Y);
                        gl.End();
                    }
                }
            }
        }


        public override void setControlPoints()
        {
            Point topLeft, topMid, topRight, midLeft, midRight, bottomLeft, bottomMid, bottomRight;
            topLeft = new Point(vertices[0].X - Rx, (vertices[0].Y - Ry));
            topMid = new Point(vertices[0].X, (vertices[0].Y - Ry));
            topRight = new Point(vertices[0].X + Rx, (vertices[0].Y - Ry));

            midLeft = new Point(vertices[0].X - Rx, vertices[0].Y);
            midRight = new Point(vertices[0].X + Rx, vertices[0].Y);

            bottomLeft = new Point(vertices[0].X - Rx, (vertices[0].Y + Ry));
            bottomMid = new Point(vertices[0].X, (vertices[0].Y + Ry));
            bottomRight = new Point(vertices[0].X + Rx, (vertices[0].Y + Ry));

            Ctrl_Points = new List<Point>();
            Ctrl_Points.Add(topLeft);
            Ctrl_Points.Add(topMid);
            Ctrl_Points.Add(topRight);
            Ctrl_Points.Add(midRight);
            Ctrl_Points.Add(bottomRight);
            Ctrl_Points.Add(bottomMid);
            Ctrl_Points.Add(bottomLeft);
            Ctrl_Points.Add(midLeft);
        }

        public override Point getCenter()
        {
            //trả về tâm ellipse
            Point center = vertices[0];
            return center;
        }
        public override int getShapeType()
        {
            int EllipseType = 2; // 2: Hình ellipse
            return EllipseType;
        }
    }
}
