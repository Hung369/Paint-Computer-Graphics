﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Square : Shape
    {
        Point VertexD; // đỉnh D
        Point VertexC; // đỉnh C
        Point VertexB; // đỉnh B
        Point VertexA; // đỉnh A

        protected string fill_mode;
        public Square(List<Point> vertices, Point Start, Point End, float thick, Color color, Color FillColor, bool isFill, string fill_mode) 
            : base(vertices, Start, End, thick, color, FillColor, isFill)
        {
            //cạnh của Hình Vuông là khoảng cách theo x của pEnd,pStart
            double dx = pEnd.X - pStart.X;
            double a = Math.Abs(dx);

            int dy = pEnd.Y - pStart.Y;

            if (dy > 0) // nếu dy > 0 thì pEnd là đỉnh C, ngược lại thì pStart là đỉnh C, lấy đỉnh C làm gốc
            {
                VertexC = pEnd;
            }
            else
            {
                VertexC = pStart;
            }
            VertexB.X = (int)a + VertexC.X;
            VertexB.Y = (int)a + VertexC.Y;

            VertexA.X = VertexC.X;
            VertexA.Y = (int)a + VertexC.Y;

            VertexD.X = (int)a + VertexC.X;
            VertexD.Y = VertexC.Y;

            this.vertices = new List<Point>();
            this.vertices.Add(VertexC);
            this.vertices.Add(VertexA);
            this.vertices.Add(VertexB);
            this.vertices.Add(VertexD);

            setControlPoints(); // thiết lập các điểm điều khiển

            this.fill_mode = fill_mode;
        }

        public override void showShape(OpenGL gl)
        {
            FillShape(gl);
            if (List_Points.Count() != 0)
            {
                List_Points.Clear();
            }
            for (int i = 0; i < 3; i++)
            {
                DrawLine(vertices[i], vertices[i + 1], gl);
            }
            DrawLine(vertices[3], vertices[0], gl);
        }


        public override void ShowEditShape(OpenGL gl)
        {
            showShape(gl);
            DrawSetControl(gl);
        }
        public override void FillShape(OpenGL gl)
        {
            if (isFill)
            {
                if (fill_mode == "flood")
                {
                    //lấy seed là điểm nằm trên trung điểm cạnh đáy
                    var cen = new Point((VertexB.X + VertexC.X) / 2, gl.RenderContextProvider.Height - ((VertexB.Y + VertexC.Y) / 2) + 1);
                    this.fill.Floodfill(cen.X, cen.Y, FillColor, color, gl);
                }
                if (fill_mode == "scan")
                    fill.ScanFill(vertices, FillColor, gl);
            }
        }

        public override void setControlPoints()
        {
            Point topLeft, topMid, topRight, midLeft, midRight, bottomLeft, bottomMid, bottomRight;
            topLeft = new Point(VertexC.X, VertexC.Y);
            topMid = new Point((int)Math.Round((VertexC.X + VertexA.X) / 2.0), VertexC.Y);
            topRight = new Point(VertexA.X, VertexA.Y);

            midLeft = new Point(VertexA.X, (int)Math.Round((VertexA.Y + VertexB.Y) / 2.0));
            midRight = new Point(VertexC.X, (int)Math.Round((VertexB.Y + VertexA.Y) / 2.0));

            bottomLeft = new Point(VertexD.X, VertexD.Y);
            bottomMid = new Point((int)Math.Round((VertexD.X + VertexB.X) / 2.0), VertexB.Y);
            bottomRight = new Point(VertexB.X, VertexB.Y);

            Ctrl_Points = new List<Point>();
            Ctrl_Points.Add(topLeft);
            Ctrl_Points.Add(topMid);
            Ctrl_Points.Add(topRight);
            Ctrl_Points.Add(midRight);
            Ctrl_Points.Add(bottomRight);
            Ctrl_Points.Add(bottomMid);
            Ctrl_Points.Add(bottomLeft);
            Ctrl_Points.Add(midLeft);
        }


        public override Point getCenter()
        {
            // trả về trọng tâm của hình vuông
            Point center_sqr = new Point((int)Math.Round((vertices[0].X + vertices[2].X) / 2.0),
                (int)Math.Round((vertices[0].Y + vertices[2].Y) / 2.0));
            return center_sqr;
        }


        public override int getShapeType()
        {
            int SquareType = 4;
            return SquareType;
        }

    }
}
