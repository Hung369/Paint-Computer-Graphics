﻿using SharpGL.SceneGraph.Primitives;
using SharpGL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Painter
    {
        public Color colorUserColor; //màu để vẽ hình

        public int ShapeType; // 0 là đường thẳng,
                              // 1 là đường tròn,
                              // 2 là hình ellipse,
                              // 3 là hình chữ nhật,
                              // 4 là hình vuông,
                              // 5 là ngũ giác đều,
                              // 6 là lục giác đều,
                              // 7 là đa giác
                              // 8 là tam giác đều

        public int old; // lưu lại loại hình đang vẽ khi edit
        public Point pStart, pEnd;
        public bool isDrawing;     //check đang vẽ hay không
        public bool isDrawDone;    //check vẽ xong hay chưa
        public bool isEdit;        //check đang chỉnh sửa hay không
        public bool isFree;        //check đang ở chế độ nào không
        public float thick;  //độ dày của nét
        public bool isClear;  // yêu cầu xóa framebuffer
        public bool isRemove;   // yêu cầu hoàn tác
        public bool isSelect; // chọn shape
        public int indexEdit; // loại hình được chọn để chỉnh sửa, mặc định bằng -1
        public double timeSpan;

        public Color color_fill; //màu tô        
        public bool isFill; //chế độ tô màu
        public string fill_mode; // loại tô màu - "scan": tô quét, "flood": tô loang.
        
        public List<Shape> shapes; // buffer hình        
        public Shape shape; // hình đang được thao tác hiện tại

       
        public Stopwatch stopwatch;  // công cụ đo thời gian

        
        public Transformation transform; // class affine transformation

        
        public List<Point> vertices; // danh sách các đỉnh 
        public int nVertices; // số đỉnh đa giác

        public List<Point> vertices_transform; // đỉnh sau khi biến đổi 

        
        public List<Point> points; // danh sách các điểm thuộc hình

        public List<Point> points_transform; // các điểm thuộc hình sau biến đổi

        public List<Point> controlPoints; // danh sách các điểm điều khiển

        public List<Point> controlPoints_transform; // các điểm điều khiển sau khi biến đổi
 
        public Point oldPos;
        
        public bool isTranslate; // check translation
        
        public bool isScale; // check scale shape
        
        public bool isRotate; // check  rotation
        
        public bool isMove1CtrlPoint; //check dịch chuyển 1 điểm điều khiển, đối với đoạn thẳng và đa giác
        //trong tâm của hình
        Point Center;
        Point Center_transform;

        public int indexCtrlPoint;
        //lưu góc khi thực hiện xoay trong khi edit
        double angle;

        // cờ báo hiệu mouseDown -> để thực hiện thao tác rotate khi edit
        public bool isDown;
        public Painter()
        {
            colorUserColor = Color.White; // màu mặc định là màu trắng, vì nền đen
            
            color_fill = Color.Red; // màu tô mặc định là màu đỏ
            
            ShapeType = 0; //mặc định vẽ đoạn thẳng

            isDrawing = false;
            isDrawDone = false;
            isEdit = false;
            isFree = true;

            thick = 1f; // mặc định = 1.0
            shapes = new List<Shape>();
            shape = null;

            isClear = false;
            isRemove = false;
            isSelect = false;
            indexEdit = -1;

            stopwatch = new Stopwatch();
            timeSpan = 0;
            isFill = false;
            fill_mode = "scan";

            vertices = new List<Point>();
            nVertices = 0;
            points = new List<Point>();
            controlPoints = new List<Point>();

            transform = null;

            isTranslate = false;
            isScale = false;
            isRotate = false;
            isDown = false;
            isMove1CtrlPoint = false;
        }

        // vẽ danh sách đối tượng hình
        public void ShowListShapes(OpenGL gl)
        {
            int n = shapes.Count();
            for (int i = 0; i < n; i++)
            {
                shapes[i].showShape(gl);
            }
        }

        // nếu user clear màn hình ->  reset các giá trị về giá trị mặc định
        public void handleClear()
        {
            if (isClear)
            {
                if (isEdit)
                {
                    shape = null;
                    isEdit = false;
                    isFree = true;
                }
                shapes.Clear();
                isClear = false;
                indexEdit = -1;
                if (vertices.Count() != 0)
                {
                    vertices.Clear();
                }
                nVertices = 0;
            }
        }

        public void handleRemove()
        {
            if (isRemove)
            {
                if (isFree) // Nếu người dùng yêu cầu xóa hình đã chọn hay hình vẽ cuối cùng
                {
                    if (shapes.Count() > 0)
                    {
                        shapes.RemoveAt(shapes.Count() - 1);
                    }
                }
                if (isEdit)
                {
                    if (indexEdit != -1)
                    {
                        shapes.RemoveAt(indexEdit);
                        indexEdit = -1;
                    }
                    shape = null;
                    isEdit = false;
                    isFree = true;
                }
                isRemove = false;
                if (vertices.Count() != 0)
                {
                    vertices.Clear();
                }
                nVertices = 0;
            }
        }
        public void createShape() // nếu đang thao tác trên shape -> cập nhật shape
        {
            if (ShapeType == 0)
            {
                shape = new Line(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill);
            }
            else if (ShapeType == 1)
            {
                shape = new Circle(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (ShapeType == 2)
            {
                shape = new Ellipse(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (ShapeType == 3)
            {
                shape = new Rectangle(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (ShapeType == 4)
            {
                shape = new Square(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (ShapeType == 5)
            {
                shape = new Pentagon(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (ShapeType == 6)
            {
                shape = new Hexagon(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (ShapeType == 7)
            {
                shape = new Polygon(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if(ShapeType == 8)
            {
                shape = new EquilTriangle(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
        }

        public void handleDrawing(OpenGL gl)
        {
            //vẽ và đo thời gian khi vẽ
            createShape();
            stopwatch.Start();
            shape.showShape(gl);
            stopwatch.Stop();

            // tính thời gian vẽ
            timeSpan = stopwatch.Elapsed.TotalMilliseconds * 1000;
            timeSpan /= 1000;
            getProperties(shape);
        }
        public void handleEdit(OpenGL gl)
        {
            shape.editShape(vertices_transform, points_transform, controlPoints_transform, thick, colorUserColor, color_fill, isFill);
            shape.ShowEditShape(gl);
        }

        public void handleDrawDone()
        {
            if (indexEdit == -1)
            {
                shapes.Add(shape);
                shape = null;
            }
            else indexEdit = -1;
            // reset vertices
            if (vertices.Count() != 0)
            {
                vertices.Clear();
            }
            nVertices = 0;

            isDrawDone = false;
            isFree = true;
        }

        // xử lí các thao tác người dùng
        public void HandlePaint(OpenGL gl)
        {
            if (isDrawing || isEdit || isDrawDone)
            {
                if (shape != null && isDrawing == false)
                {
                    shape.showShape(gl);
                }
                if (isDrawing)
                    handleDrawing(gl);
                if (isEdit)
                    handleEdit(gl);
                if (isDrawDone)
                    handleDrawDone();

                stopwatch.Reset();
            }
        }

        public void getProperties(Shape sh)
        {
            vertices = sh.getVertices();
            vertices_transform = sh.getVertices();

            points = sh.getPoints();
            points_transform = sh.getPoints();

            controlPoints = sh.getCtrlPoints();
            controlPoints_transform = sh.getCtrlPoints();

            thick = sh.getThick();
            colorUserColor = sh.GetColor();
            color_fill = sh.getFillColor();
            isFill = sh.getFillVal();

            Center = shape.getCenter();
            Center_transform = shape.getCenter();

            old = ShapeType;
            ShapeType = sh.getShapeType();
        }

        public void turnOffActiveMode()
        {
            if (isDrawing || isEdit)
            {
                isDrawDone = true;
                isDrawing = false;
                isEdit = false;
            }

            if (isSelect)
            {
                isSelect = false;
            }

            if (isRotate)
            {
                isRotate = false;
            }
        }

        public void Translation()
        {
            // thực hiện affine lên tập đỉnh, tập điểm điều khiển, tập điểm (nếu cần)
            vertices_transform = transform.TransformListPoint(vertices);
            controlPoints_transform = transform.TransformListPoint(controlPoints);
            if (ShapeType == 1 || ShapeType == 2)
            {
                points_transform = transform.TransformListPoint(points);
            }
            Center_transform = transform.TransformPoint(Center);
        }

        public void finishTransform()
        {
            vertices = vertices_transform;
            controlPoints = controlPoints_transform;
            points = points_transform;
            Center = Center_transform;
            if (isRotate)
                shape.angleRotating += angle;
        }


        public void Scaling(Point cur) // hàm thực hiện scale ảnh
        {
            //vector current 
            Point current = new Point(cur.X - Center.X, cur.Y - Center.Y);
            double len_cur = Math.Sqrt(current.X * current.X + current.Y * current.Y);
            //vector previous
            Point previous = new Point(oldPos.X - Center.X, oldPos.Y - Center.Y);
            double len_prev = Math.Sqrt(previous.X * previous.X + previous.Y * previous.Y);

            double sx, sy;
            // các đa giác đều và hình tròn -> scale có Sx = Sy -> không bị biến dạng
            if (ShapeType == 1 || ShapeType == 4 || ShapeType == 5 || ShapeType == 6 || ShapeType == 8)
            {
                sy = sx = len_cur / len_prev;
            }
            else if (ShapeType == 3 || ShapeType == 2)
            {
                if (indexCtrlPoint == 1 || indexCtrlPoint == 5)
                {
                    sx = 1;
                    sy = len_cur / len_prev;
                }
                else if (indexCtrlPoint == 7 || indexCtrlPoint == 3)
                {
                    //nếu là mid_left hay mid_right -> scale theo phương ngang
                    sx = len_cur / len_prev;
                    sy = 1;
                }
                else
                {
                    // nếu là các điểm ở cac góc
                    sx = current.X * 1.0 / previous.X; // cast về float datatype
                    sy = current.Y * 1.0 / previous.Y;
                }
            }
            else
            {
                sx = current.X * 1.0 / previous.X;
                sy = current.Y * 1.0 / previous.Y;
            }

            //scale shape
            transform = new Transformation(sx, sy, Center);

            //thực hiện affine lên tập đỉnh, tập điểm điều khiển, tập điểm (nếu cần)
            if (ShapeType == 2) // hình ellipse
            {
                Transformation epl = new Transformation(-shape.angleRotating, Center);
                List<Point> TempVertices = epl.TransformListPoint(vertices);
                TempVertices = transform.TransformListPoint(TempVertices);

                //tạo mới ellipse nếu scale
                Shape tempElip = new Ellipse(null, TempVertices[0], TempVertices[1], thick, colorUserColor, color_fill, isFill, fill_mode);
                List<Point> TempPoints = tempElip.getPoints();

                //tạo mới các điểm điều khiển tương ứng với elip mới
                shape.setControlPoints();
                List<Point> TempCtrlPoints = tempElip.getCtrlPoints();

                //xoay listPoints và list ControlPoints theo góc angleRotating
                transform = new Transformation(shape.angleRotating, Center);
                vertices_transform = transform.TransformListPoint(TempVertices);
                points_transform = transform.TransformListPoint(TempPoints);
                controlPoints_transform = transform.TransformListPoint(TempCtrlPoints);
            }
            else if (ShapeType == 3) // hình chữ nhật
            {
                Transformation rec = new Transformation(-shape.angleRotating, Center);
                List<Point> TempVertices = rec.TransformListPoint(vertices);
                TempVertices = transform.TransformListPoint(TempVertices);

                // tạo mới hcn nếu scale
                Shape tempRec = new Rectangle(null, TempVertices[0], TempVertices[2], thick, colorUserColor, color_fill, isFill, fill_mode);

                List<Point> TempCtrlPoints = tempRec.getCtrlPoints();

                // xoay listPoints và list ControlPoints theo góc angleRotating
                transform = new Transformation(shape.angleRotating, Center);
                vertices_transform = transform.TransformListPoint(TempVertices);
                controlPoints_transform = transform.TransformListPoint(TempCtrlPoints);
            }
            else
            {
                vertices_transform = transform.TransformListPoint(vertices);
                controlPoints_transform = transform.TransformListPoint(controlPoints);
                if (ShapeType == 1)
                {
                    shape.setVertices(vertices_transform);
                    shape.calculateListPoints();
                    points_transform = shape.getPoints();
                }
            }
        }

        public void Rotation(Point cur)
        {
            // vector current center
            Point current = new Point(cur.X - Center.X, cur.Y - Center.Y);
            double len_cur = Math.Sqrt(current.X * current.X + current.Y * current.Y); // module vector

            // vector previous center
            Point previous = new Point(oldPos.X - Center.X, oldPos.Y - Center.Y);
            double len_prev = Math.Sqrt(previous.X * previous.X + previous.Y * previous.Y); // module vector

            angle = Math.Acos((current.X * previous.X + current.Y * previous.Y) / (len_cur * len_prev));
            // ngược chiều kim đồng hồ -> cur nằm bên trái previous
            //=> xét thành phần z của tích có hướng của current và previous
            if (previous.X * current.Y - previous.Y * current.X < 0)
            {
                angle *= -1;
            }


            transform = new Transformation(angle, Center);
            vertices_transform = transform.TransformListPoint(vertices);
            if (ShapeType == 1 || ShapeType == 2) // đường tròn, hình ellipse,
            {
                points_transform = transform.TransformListPoint(points);
            }
            controlPoints_transform = transform.TransformListPoint(controlPoints);
        }

        public void handleMove1CtrlPoint(Point cur)
        {
            vertices_transform[indexCtrlPoint] = cur;
            controlPoints_transform[indexCtrlPoint] = cur;
        }
    }
}
