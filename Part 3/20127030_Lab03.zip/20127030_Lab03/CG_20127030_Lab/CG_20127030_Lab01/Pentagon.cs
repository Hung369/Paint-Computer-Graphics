﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Pentagon : Shape
    {
        // AB là đáy dưới, E là điểm trái nhất
        Point A, B, C, D, E;
        protected string fill_mode;
        public Pentagon(List<Point> vertices, Point Start, Point End, float thick, Color color, Color color_fill, bool isFill, string fill_mode)
            : base(vertices, Start, End, thick, color, color_fill, isFill)
        {
            // Khoảng cách khối theo Oy
            int dy = End.Y - Start.Y;
            // Khoảng cách khối theo Ox
            int dx = End.X - Start.X;

            // tính cạnh của ngũ giác đều
            double alpha = 72 * 3.14 / 180; // góc kề bù với góc trong = 72 độ -> đổi qua radian
            double a = Math.Abs(dx) / (2 * Math.Cos(alpha) + 1); // độ dài cạnh của ngũ giác
            double w = a * Math.Cos(alpha); // tính độ dài khi chiếu lên Ox
            double h = a * Math.Sin(alpha); // tính độ cao khi chiếu lên Oy
            double beta = 54 * 3.14 / 180; // góc tạo bởi bán kính đường tròn nội tiếp và cạnh ngũ giác
            double h1 = a * Math.Cos(beta); // bán kính đường tròn nội tiếp

            if (dy < 0) // Nếu End nằm trên Start
            {
                A.Y = Start.Y;
                B.Y = Start.Y;
            }
            else  // End bằm dưới Start hay End.y = Start.y
            {
                A.Y = End.Y;
                B.Y = End.Y;
            }

            D.X = (int)Math.Round((End.X + Start.X) / 2.0);
            D.Y = -(int)h1 - (int)h + A.Y;

            E.Y = -(int)h + A.Y;
            C.Y = E.Y;

            if (dx > 0) //nếu End nằm bên phải Start
            {
                E.X = Start.X;
                C.X = End.X;
            }
            else  //nếu End nằm bên trái Start hay End.X = Start.X
            {
                E.X = End.X;
                C.X = Start.X;
            }
            A.X = E.X + (int)w;
            B.X = C.X - (int)w;

            this.vertices = new List<Point>();
            this.vertices.Add(A);
            this.vertices.Add(B);
            this.vertices.Add(C);
            this.vertices.Add(D);
            this.vertices.Add(E);
            setControlPoints();  //thiết lập các điểm điều khiển

            this.fill_mode = fill_mode;
        }
        public override void showShape(OpenGL gl)
        {
            FillShape(gl);
            if (List_Points.Count() != 0)
            {
                List_Points.Clear();
            }
            for (int i = 0; i < 4; i++)
            {
                DrawLine(vertices[i], vertices[i + 1], gl);
            }
            DrawLine(vertices[4], vertices[0], gl);
        }

        public override void editShape(List<Point> vertices, List<Point> points, List<Point> controlPoints, float thick, Color color, Color color_fill, bool isFill)
        {
            base.editShape(vertices, points, controlPoints, thick, color, color_fill, isFill);
        }
        public override void ShowEditShape(OpenGL gl)
        {
            showShape(gl);
            DrawSetControl(gl);
        }
        public override void FillShape(OpenGL gl)
        {
            if (isFill)
            {
                if (fill_mode == "flood")
                {
                    //lấy trung điểm đoạn thẳng CE
                    var cen = new Point((C.X + E.X) / 2, gl.RenderContextProvider.Height - (C.Y + E.Y) / 2);
                    this.fill.Floodfill(cen.X, cen.Y, FillColor, color, gl);
                }
                if(fill_mode == "scan")
                    fill.ScanFill(vertices, FillColor, gl);
            }
        }


        public override void setControlPoints()
        {
            Point topLeft, topMid, topRight, midLeft, midRight, bottomLeft, bottomMid, bottomRight;
            topLeft = new Point(E.X, D.Y);
            topMid = new Point(D.X, D.Y);
            topRight = new Point(C.X, D.Y);

            midLeft = new Point(E.X, (int)Math.Round((A.Y + D.Y) / 2.0));
            midRight = new Point(C.X, (int)Math.Round((A.Y + D.Y) / 2.0));

            bottomLeft = new Point(E.X, B.Y);
            bottomMid = new Point(D.X, B.Y);
            bottomRight = new Point(C.X, B.Y);

            Ctrl_Points = new List<Point>();
            Ctrl_Points.Add(topLeft);
            Ctrl_Points.Add(topMid);
            Ctrl_Points.Add(topRight);
            Ctrl_Points.Add(midRight);
            Ctrl_Points.Add(bottomRight);
            Ctrl_Points.Add(bottomMid);
            Ctrl_Points.Add(bottomLeft);
            Ctrl_Points.Add(midLeft);
        }


        public override Point getCenter()
        {

            this.vertices.Add(A);
            this.vertices.Add(B);
            this.vertices.Add(C);
            this.vertices.Add(D);
            this.vertices.Add(E);

            //trung điểm M của AE
            Point M = new Point((vertices[0].X + vertices[4].X) / 2, (vertices[0].Y + vertices[4].Y) / 2);

            // trung điểm N của BC
            Point N = new Point((vertices[1].X + vertices[2].X) / 2, (vertices[1].Y + vertices[2].Y) / 2);

            //trung điểm P của MN
            Point P = new Point((M.X + N.X) / 2, (M.Y + N.Y) / 2);

            //trọng tâm của hình là điểm G sao cho GD = 4*DP
            Point G = new Point((vertices[4].X + 4 * P.X) / 5, (vertices[4].Y + 4 * P.Y) / 5);
            return G;
        }


        public override int getShapeType()
        {
            int PentaShape = 5; // 5: pentagon
            return PentaShape;
        }
    }
}
