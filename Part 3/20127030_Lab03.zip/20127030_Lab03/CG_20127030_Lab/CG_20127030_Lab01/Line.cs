﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Line : Shape
    {
        public Line(List<Point> vertices, Point Start, Point End, float thick, Color color, Color color_fill, bool isFill) 
            : base(vertices, Start, End, thick, color, color_fill, isFill)
        {
            this.vertices = new List<Point>();
            this.vertices.Add(Start);
            this.vertices.Add(End);
            setControlPoints();
        }

        public override void showShape(OpenGL gl)
        {
            if (List_Points.Count() != 0)
            {
                List_Points.Clear();
            }
            DrawLine(vertices[0], vertices[1], gl);
        }

        public override void ShowEditShape(OpenGL gl)
        {
            showShape(gl);
            DrawSetControl(gl);
        }

        public override void setControlPoints() // thiết lập các điểm điều khiển
        {
            Ctrl_Points = new List<Point>();
            Ctrl_Points.Add(pStart);
            Ctrl_Points.Add(pEnd);
        }

        public override bool isOnShape(Point cur)
        {
            int n = List_Points.Count();
            for (int i = 8; i < n - 8; i++)
            {
                if (Math.Abs(List_Points[i].X - cur.X) < 5 && Math.Abs(List_Points[i].Y - cur.Y) < 5)
                {
                    return true;
                }
            }
            return false;
        }

        public override Point getCenter() // trả về trung điểm đoạn thẳng
        {
            Point center_line = new Point((vertices[0].X + vertices[1].X)/2, (vertices[0].Y + vertices[1].Y)/2);
            return center_line;
        }


        public override int getShapeType()
        {
            int LineType = 0; // 0: ký hiệu cho vẽ đoạn thẳng
            return LineType;
        }
    }
}
