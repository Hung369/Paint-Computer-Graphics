﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Transformation
    {
        double[][] aff_mat; // affine transformation matrix

        public Transformation(double sx, double sy, Point center) // Resize
        {
            aff_mat = new double[3][];
            aff_mat[0] = new double[] { sx, 0, -center.X * sx + center.X };
            aff_mat[1] = new double[] { 0, sy, -center.Y * sy + center.Y };
            aff_mat[2] = new double[] { 0, 0, 1 };
        }
        
        public Transformation(double angle, Point center) // Rotation
        {
            aff_mat = new double[3][];
            double cos_a = Math.Cos(angle), sin_a = Math.Sin(angle);
            aff_mat[0] = new double[] { cos_a, -sin_a, -center.X * cos_a + center.Y * sin_a + center.X };
            aff_mat[1] = new double[] { sin_a, cos_a, -center.X * sin_a - center.Y * cos_a + center.Y };
            aff_mat[2] = new double[] { 0, 0, 1 };
        }
        
        public Transformation(int val_x, int val_y) // Translation
        {
            aff_mat = new double[3][];
            aff_mat[0] = new double[] { 1, 0, val_x };
            aff_mat[1] = new double[] { 0, 1, val_y };
            aff_mat[2] = new double[] { 0, 0, 1 };
        }

        public Point TransformPoint(Point p) // Điểm mới sau khi dịch chuyển
        {
            Point result = new Point();
            result.X = (int)Math.Round(aff_mat[0][0] * p.X + aff_mat[0][1] * p.Y + aff_mat[0][2]);
            result.Y = (int)Math.Round(aff_mat[1][0] * p.X + aff_mat[1][1] * p.Y + aff_mat[1][2]);
            return result;
        }

        public List<Point> TransformListPoint(List<Point> lp) // Danh sách lưu các điểm mới khi dịch chuyển
        {
            int n = lp.Count();
            List<Point> result = new List<Point>();
            for (int i = 0; i < n; i++)
            {
                result.Add(TransformPoint(lp[i]));
            }
            return result;
        }
    }
}
