﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class EquilTriangle :Shape
    {
        Point VertexC; // đỉnh C
        Point VertexB; //đỉnh B
        Point VertexA; //dỉnh A
        protected string fill_mode;

        public EquilTriangle(List<Point> vertices, Point Start, Point End, float thick, Color color, Color color_fill, bool isFill, string fill_mode)
            : base(vertices, Start, End, thick, color, color_fill, isFill)
        {
            //cạnh của tam giác
            double a = Math.Abs(pEnd.X - pStart.X);

            //chiều cao của tam giác
            double h = Math.Sqrt(3) * a / 2;

            int dy = pEnd.Y - pStart.Y;

            //nếu dy > 0 thì pEnd là đỉnh C, ngược lại thì pStart là đỉnh C
            if (dy > 0)
            {
                VertexC = pEnd;
                VertexB.X = pStart.X;
                VertexB.Y = pEnd.Y;
            }
            else
            {
                VertexC = pStart;
                VertexB.X = pEnd.X;
                VertexB.Y = pStart.Y;
            }

            // Tính tọa độ điểm A theo tính chất đường trung trực
            VertexA.X = (int)Math.Round((VertexB.X + VertexC.X) / 2.0);
            VertexA.Y = -(int)Math.Round(h) + VertexB.Y;


            this.vertices = new List<Point>();
            this.vertices.Add(VertexA);
            this.vertices.Add(VertexB);
            this.vertices.Add(VertexC);


            //thiết lập các điểm điều khiển
            setControlPoints();
        }

        public override void showShape(OpenGL gl)
        {
            FillShape(gl);
            if (List_Points.Count() != 0)
            {
                List_Points.Clear();
            }
            for (int i = 0; i < 2; i++)
            {
                DrawLine(vertices[i], vertices[i + 1], gl);
            }
            DrawLine(vertices[2], vertices[0], gl);
        }

        public override void ShowEditShape(OpenGL gl)
        {
            showShape(gl);
            DrawSetControl(gl);
        }

        public override void FillShape(OpenGL gl)
        {
            if (isFill)
            {
                if (fill_mode == "flood")
                {
                    //lấy điểm là tâm đường tròn
                    var cen = new Point(pStart.X, pStart.Y);
                    this.fill.Floodfill(cen.X, cen.Y, FillColor, color, gl);
                }
                else
                {
                    fill.ScanFill(vertices, FillColor, gl);
                }
            }
        }

        public override void setControlPoints()
        {
            Point topLeft, topMid, topRight, midLeft, midRight, bottomLeft, bottomMid, bottomRight;
            topLeft = new Point(VertexB.X, VertexA.Y);
            topMid = new Point(VertexA.X, VertexA.Y);
            topRight = new Point(VertexC.X, VertexA.Y);

            midLeft = new Point(VertexB.X, (int)Math.Round((VertexB.Y + VertexA.Y) / 2.0));
            midRight = new Point(VertexC.X, (int)Math.Round((VertexB.Y + VertexA.Y) / 2.0));

            bottomLeft = new Point(VertexB.X, VertexB.Y);
            bottomMid = new Point((int)Math.Round((VertexB.X + VertexC.X) / 2.0), VertexB.Y);
            bottomRight = new Point(VertexC.X, VertexB.Y);

            Ctrl_Points = new List<Point>();
            Ctrl_Points.Add(topLeft);
            Ctrl_Points.Add(topMid);
            Ctrl_Points.Add(topRight);
            Ctrl_Points.Add(midRight);
            Ctrl_Points.Add(bottomRight);
            Ctrl_Points.Add(bottomMid);
            Ctrl_Points.Add(bottomLeft);
            Ctrl_Points.Add(midLeft);
        }


        public override Point getCenter()
        {
            //trả về trọng tâm tam giác
            Point center = new Point((vertices[0].X + vertices[1].X + vertices[2].X) / 3, 
                (vertices[0].Y + vertices[1].Y + vertices[2].Y) / 3);
            return center;
        }


        public override int getShapeType()
        {
            int equilTri = 8;
            return equilTri;
        }
    }
}
