﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Circle : Shape
    {
        //tâm đường tròn là  pStart ở class Shape
        double radius;
        protected string fill_mode;
        public Circle(List<Point> vertices, Point Start, Point End, float thick, Color color, Color color_fill, bool isFill, string fill_mode) 
            : base(vertices, Start, End, thick, color, color_fill, isFill)
        {

            //tạo list vertices chứa tâm và 1 điểm nằm trên đường tròn
            this.vertices = new List<Point>();
            this.vertices.Add(pStart);
            this.vertices.Add(pEnd);

            // tính toán các điểm thuộc đường tròn và đưa vào list_point
            calculateListPoints();

            //thiết lập các điểm điều khiển
            setControlPoints();

            this.fill_mode = fill_mode;
        }

        public override void calculateListPoints()
        {
            radius = Math.Sqrt((vertices[1].X - vertices[0].X) * (vertices[1].X - vertices[0].X) + (vertices[1].Y - vertices[0].Y) * (vertices[1].Y - vertices[0].Y));

            int r = (int)Math.Round(radius);

            //tập hợp điểm trên đường tròn
            if (List_Points.Count() != 0)
            {
                List_Points.Clear();
            }

            Point CenterPoint = new Point();
            CenterPoint.Y = vertices[0].Y;
            CenterPoint.X = vertices[0].X;

            //điểm đầu tiên
            Point point = new Point(0, r);

            //thêm 4 điểm nằm trên trục vào list
            Point value = new Point(); // điểm (0,r)
            value.X = CenterPoint.X;
            value.Y = r + CenterPoint.Y;
            List_Points.Add(value);

            
            value.Y = -r + CenterPoint.Y; // điểm (0,-r)
            List_Points.Add(value);
            
            value.X = r + CenterPoint.X; // điểm (r,0)
            value.Y = CenterPoint.Y;
            List_Points.Add(value);
            
            value.X = -r + CenterPoint.X; // điểm (-r,0)
            List_Points.Add(value);

            int p = (5/4) - r;

            // vẽ đường tròn
            while (point.X < point.Y)
            {
                if (p < 0)
                {
                    point.X += 1;
                    p += 2 * point.X + 1;
                }
                else
                {
                    point.X += 1;
                    point.Y -= 1;
                    p += 2 * point.X - 2 * point.Y + 1;
                }

                //điểm I(x,y) tịnh tiến point và thêm vào list
                Point temp = new Point();
                temp.X = point.X + CenterPoint.X;
                temp.Y = point.Y + CenterPoint.Y;
                List_Points.Add(temp);

                // Lấy 7 điểm đối xứng với temp qua các trục x=0,y=0,y=-x,y=x và thêm vào list
                
                Point diem1 = new Point(); // điểm 1(y,x)
                diem1.X = point.Y + CenterPoint.X;
                diem1.Y = point.X + CenterPoint.Y;
                List_Points.Add(diem1);
                
                Point diem2 = new Point(); // điểm 2(y,-x)
                diem2.X = point.Y + CenterPoint.X;
                diem2.Y = -point.X + CenterPoint.Y;
                List_Points.Add(diem2);
                
                Point diem3 = new Point(); // điểm 3(x,-y)
                diem3.X = point.X + CenterPoint.X;
                diem3.Y = -point.Y + CenterPoint.Y;
                List_Points.Add(diem3);
                
                Point diem4 = new Point(); // điểm 4(-x,-y)
                diem4.X = -point.X + CenterPoint.X;
                diem4.Y = -point.Y + CenterPoint.Y;
                List_Points.Add(diem4);
                
                Point diem5 = new Point(); // điểm 5(-y,-x)
                diem5.X = -point.Y + CenterPoint.X;
                diem5.Y = -point.X + CenterPoint.Y;
                List_Points.Add(diem5);
                
                Point diem6 = new Point(); // điểm 6(-y,x)
                diem6.X = -point.Y + CenterPoint.X;
                diem6.Y = point.X + CenterPoint.Y;
                List_Points.Add(diem6);
                
                Point diem7 = new Point(); // điểm 7(-x,y)
                diem7.X = -point.X + CenterPoint.X;
                diem7.Y = point.Y + CenterPoint.Y;
                List_Points.Add(diem7);
            }

        }
        public override void showShape(OpenGL gl)
        {
           
            FillShape(gl);  //tô màu
            DrawListPoint(List_Points, gl); //vẽ đường tròn với tập hợp điểm
        }

        public override void editShape(List<Point> vertices, List<Point> points, List<Point> controlPoints, float thick, Color color, Color color_fill, bool isFill)
        {
            base.editShape(vertices, points, controlPoints, thick, color, color_fill, isFill);
            List_Points = new List<Point>(points);
        }
        public override void ShowEditShape(OpenGL gl)
        {
            showShape(gl);
            DrawSetControl(gl);
        }

        public override void FillShape(OpenGL gl)
        {
            if (isFill)
            {
                if (fill_mode == "flood")
                {
                    //lấy điểm là tâm đường tròn
                    var cen = new Point(pStart.X, pStart.Y);
                    this.fill.Floodfill(cen.X, cen.Y, FillColor, color, gl);
                }

                int ymin = int.MaxValue, ymax = int.MinValue;
                int n = List_Points.Count();
                for (int i = 0; i < n; i++)
                {
                    int ycur = List_Points[i].Y;
                    if (ycur > ymax)
                    {
                        ymax = ycur;
                    }
                    if (ycur < ymin)
                    {
                        ymin = ycur;
                    }
                }
                Point A, B;
                for (int y = ymin + 1; y < ymax; y++)
                {
                    A = List_Points.Find(c => c.Y == y);
                    B = List_Points.Find(c => c.Y == y && c.X != A.X);
                    if (A.IsEmpty || B.IsEmpty)
                    {
                        continue;
                    }
                    gl.Color(FillColor.R / 255.0, FillColor.G / 255.0, FillColor.B / 255.0);
                    gl.Begin(OpenGL.GL_LINES);
                    gl.Vertex(A.X, gl.RenderContextProvider.Height - A.Y);
                    gl.Vertex(B.X, gl.RenderContextProvider.Height - B.Y);
                    gl.End();
                }
            }
        }



        public override void setControlPoints()
        {
            int r = (int)radius;

            Point topLeft, topMid, topRight, midLeft, midRight, bottomLeft, bottomMid, bottomRight;
            topLeft = new Point(pStart.X - r, (pStart.Y - r));
            topMid = new Point(pStart.X, (pStart.Y - r));
            topRight = new Point(pStart.X + r, (pStart.Y - r));

            midLeft = new Point(pStart.X - r, pStart.Y);
            midRight = new Point(pStart.X + r, pStart.Y);

            bottomLeft = new Point(pStart.X - r, (pStart.Y + r));
            bottomMid = new Point(pStart.X, (pStart.Y + r));
            bottomRight = new Point(pStart.X + r, (pStart.Y + r));

            Ctrl_Points = new List<Point>();
            Ctrl_Points.Add(topLeft);
            Ctrl_Points.Add(topMid);
            Ctrl_Points.Add(topRight);
            Ctrl_Points.Add(midRight);
            Ctrl_Points.Add(bottomRight);
            Ctrl_Points.Add(bottomMid);
            Ctrl_Points.Add(bottomLeft);
            Ctrl_Points.Add(midLeft);
        }

        public override Point getCenter()
        {
            //trả về tâm đường tròn
            Point p = vertices[0];
            return p;
        }

        public override int getShapeType()
        {
            int CircleType = 1; // 1: Kiểu vẽ đường tròn
            return CircleType;
        }
    }
}
