﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Polygon : Shape
    {
        protected string fill_mode;
        public Polygon(List<Point> vertices, Point Start, Point End, float thick, Color color, Color color_fill, bool isFill, string fill_mode) 
            : base(vertices, Start, End, thick, color, color_fill, isFill)
        {
            isPolygon = true;
            this.vertices = new List<Point>(vertices);

            //thiết lập các điểm điều khiển
            setControlPoints();

            this.fill_mode = fill_mode;
        }

        public override void showShape(OpenGL gl)
        {
            FillShape(gl);
            if (List_Points.Count() != 0)
            {
                List_Points.Clear();
            }
            int n = vertices.Count();
            if (n == 0)
            {
                return;
            }
            for (int i = 0; i < n - 1; i++)
            {
                DrawLine(vertices[i], vertices[i + 1], gl);
            }
            DrawLine(vertices[n - 1], vertices[0], gl);
        }

        public override void editShape(List<Point> vertices, List<Point> points, List<Point> controlPoints, float thick, Color color, Color color_fill, bool isFill)
        {
            base.editShape(vertices, points, controlPoints, thick, color, color_fill, isFill);
        }
        public override void ShowEditShape(OpenGL gl)
        {
            showShape(gl);
            DrawSetControl(gl);
        }
        public override void FillShape(OpenGL gl)
        {
            if (isFill)
            {
                if (fill_mode == "flood")
                {
                    //lấy seed là điểm nằm trên trung điểm cạnh đáy
                    var cen = new Point();
                    this.fill.Floodfill(cen.X, cen.Y, FillColor, color, gl);
                }
                if (fill_mode == "scan")
                    fill.ScanFill(vertices, FillColor, gl);
            }
        }


        public override void setControlPoints()
        {
            int n = vertices.Count();
            Ctrl_Points = new List<Point>();
            for (int i = 0; i < n; i++)
            {
                Point vertex = new Point(vertices[i].X, vertices[i].Y);
                Ctrl_Points.Add(vertex);
            }
        }

        public override Point getCenter()
        {
            int y_min = int.MaxValue, y_max = int.MinValue; // tìm y_min,y_max
            int x_min = int.MaxValue, x_max = int.MinValue; // tìm x_min, x_max
            for (int i = 0; i < vertices.Count(); i++)
            {
                if (x_min > vertices[i].X)
                    x_min = vertices[i].X;
                if (x_max < vertices[i].X)
                    x_max = vertices[i].X;
                if (y_min > vertices[i].Y)
                    y_min = vertices[i].Y;
                if (y_max < vertices[i].Y)
                    y_max = vertices[i].Y;
            }
            Point center = new Point((int)Math.Round((x_min + x_max) / 2.0), (int)Math.Round((y_min + y_max) / 2.0));
            return center;
        }


        public override int getShapeType()
        {
            int PolyType = 7;
            return PolyType;
        }
    }
}
