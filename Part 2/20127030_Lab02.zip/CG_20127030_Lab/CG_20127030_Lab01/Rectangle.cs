﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Rectangle : Shape
    {
        // pStart là đỉnh 1, pEnd là đỉnh 3; set 2 điểm đó làm gốc
        Point vertex2; // đỉnh 2
        Point vertex4; // đỉnh 4

        protected string fill_mode;
        public Rectangle(List<Point> vertices, Point Start, Point End, float thick, Color color, Color color_fill, bool isFill, string fill_mode) 
            : base(vertices, Start, End, thick, color, color_fill, isFill)
        {
            vertex2.X = End.X;
            vertex2.Y = Start.Y;
            vertex4.X = Start.X;
            vertex4.Y = End.Y;

            this.vertices = new List<Point>();
            this.vertices.Add(pStart);
            this.vertices.Add(vertex2);
            this.vertices.Add(pEnd);
            this.vertices.Add(vertex4);

            setControlPoints(); // thiết lập các điểm điều khiển

            this.fill_mode = fill_mode;
        }

        public override void showShape(OpenGL gl)
        {
            FillShape(gl);
            if (List_Points.Count() != 0)
            {
                List_Points.Clear();
            }
            for (int i = 0; i < 3; i++)
            {
                DrawLine(vertices[i], vertices[i + 1], gl);
            }
            DrawLine(vertices[3], vertices[0], gl);

        }

        public override void editShape(List<Point> vertices, List<Point> points, List<Point> controlPoints, float thick, Color color, Color color_fill, bool isFill)
        {
            base.editShape(vertices, points, controlPoints, thick, color, color_fill, isFill);
        }
        public override void ShowEditShape(OpenGL gl)
        {
            showShape(gl);
            DrawSetControl(gl);
        }

        public override void FillShape(OpenGL gl)
        {
            if (this.isFill)
            {
                //tô loang
                if (fill_mode == "flood")
                {
                    // lấy tâm hình chữ nhật
                    var center = new Point((pStart.X + pEnd.X) / 2, gl.RenderContextProvider.Height - (pStart.Y + pEnd.Y) / 2);
                    this.fill.Floodfill(center.X, center.Y, FillColor, color, gl);
                }
                // tô quét
                if (fill_mode == "scan")
                    fill.ScanFill(vertices, FillColor, gl);
            }
        }

        public override void setControlPoints()
        {
            // khai báo lần lượt các điểm góc và trung điểm các cạnh của HCN
            Point topLeft, topMid, topRight, midLeft, midRight, bottomLeft, bottomMid, bottomRight;

            topLeft = new Point(pStart.X, pStart.Y);
            topMid = new Point((int)Math.Round((pStart.X + pEnd.X) / 2.0), pStart.Y);
            topRight = new Point(pEnd.X, pStart.Y);

            midLeft = new Point(pStart.X, (int)Math.Round((pStart.Y + pEnd.Y) / 2.0));
            midRight = new Point(pEnd.X, (int)Math.Round((pStart.Y + pEnd.Y) / 2.0));

            bottomLeft = new Point(pStart.X, pEnd.Y);
            bottomMid = new Point((int)Math.Round((pStart.X + pEnd.X) / 2.0), pEnd.Y);
            bottomRight = new Point(pEnd.X, pEnd.Y);

            Ctrl_Points = new List<Point>();
            Ctrl_Points.Add(topLeft);
            Ctrl_Points.Add(topMid);
            Ctrl_Points.Add(topRight);
            Ctrl_Points.Add(midRight);
            Ctrl_Points.Add(bottomRight);
            Ctrl_Points.Add(bottomMid);
            Ctrl_Points.Add(bottomLeft);
            Ctrl_Points.Add(midLeft);
        }


        public override Point getCenter()
        {
            //trả về tâm của HCN
            Point center_rec = new Point((int)Math.Round((vertices[0].X + vertices[2].X) / 2.0), 
                (int)Math.Round((vertices[0].Y + vertices[2].Y) / 2.0));
            return center_rec;
        }


        public override int getShapeType()
        {
            int RecType = 3; // 3 là hình chữ nhật
            return RecType;
        }
    }
}
