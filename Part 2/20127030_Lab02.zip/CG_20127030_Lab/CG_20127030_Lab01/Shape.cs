﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Shape
    {
        
        protected List<Point> vertices; // danh sách các đỉnh

        protected Point pStart, pEnd;  // điểm bắt đầu và kết thúc.

        protected float thickness; // độ dày nét vẽ
        
        protected Color color; // màu nét vẽ
        
        protected Color FillColor; // màu để tô
        
        protected bool isFill; // chế độ tô màu (tô loang, tô kẻ sọc)
        
        protected List<Point> List_Points; // danh sách điểm của hình
        
        public List<Point> Ctrl_Points; // danh sách điểm điều khiển của hình
        
        protected Fill fill; //class tô màu

        protected bool isPolygon; // check có phải đa giác.
        
        public double angleRotating; //lưu góc mà hình đã được quay -> trạng thái sau khi xoay
        public Shape(List<Point> vertices, Point Start, Point End, float thickness, Color color, Color color_fill, Boolean isFill)
        {
            isPolygon = false;
            pStart = Start;
            pEnd = End;
            this.thickness = thickness;
            this.color = color;
            this.FillColor = color_fill;
            this.isFill = isFill;
            fill = new Fill();
            List_Points = new List<Point>();
            angleRotating = 0;
        }

        public virtual void calculateListPoints()
        {

        }
        public virtual void showShape(OpenGL gl) // hiển thị hình vẽ.
        {

        }

        public virtual void FillShape(OpenGL gl) // tô màu hình vẽ.
        {

        }

        public virtual void editShape(List<Point> vertices, List<Point> points, List<Point> controlPoints, float thickness, Color color, Color color_fill, bool isFill)
        {
            this.thickness = thickness;
            this.color = color;
            this.FillColor = color_fill;
            this.isFill = isFill;
            this.vertices = new List<Point>(vertices);
            this.Ctrl_Points = new List<Point>(controlPoints);
        }

        public virtual void ShowEditShape(OpenGL gl) // hiển thị kết quả điều chỉnh hình vẽ.
        {

        }
        
        public virtual void setControlPoints() // tạo danh sách điểm điều khiển
        {

        }
        
        public void DrawSetControl(OpenGL gl) //vẽ tập điểm điều khiển 
        {
            int n = Ctrl_Points.Count();
            if (n == 8 && isPolygon != true)
            {
                int GLHeight = gl.RenderContextProvider.Height;
                Color a = Color.Indigo;
                gl.Color(a.R / 255.0, a.R / 255.0, a.B / 255.0);
                gl.LineWidth(1f);
                gl.Enable(OpenGL.GL_LINE_STIPPLE);
                gl.LineStipple(4, 0xAAAA);
                gl.Begin(OpenGL.GL_LINE_STRIP);
                gl.Vertex(Ctrl_Points[0].X + 1, GLHeight - Ctrl_Points[0].Y);
                gl.Vertex(Ctrl_Points[2].X + 1, GLHeight - Ctrl_Points[2].Y);
                gl.Vertex(Ctrl_Points[4].X + 1, GLHeight - Ctrl_Points[4].Y);
                gl.Vertex(Ctrl_Points[6].X + 1, GLHeight - Ctrl_Points[6].Y);
                gl.Vertex(Ctrl_Points[0].X + 1, GLHeight - Ctrl_Points[0].Y);
                gl.End();
                gl.Flush();
                gl.Disable(OpenGL.GL_LINE_STIPPLE);

                for (int i = 0; i < n; i++)
                {
                    DrawControlPoint(gl, Ctrl_Points[i]);
                }
            }
            else
            {
                // trường hợp là đường thẳng hoặc đa giác
                for (int i = 0; i < n; i++)
                {
                    DrawControlPoint(gl, Ctrl_Points[i]);
                }
            }
        }
        public void DrawControlPoint(OpenGL gl, Point p)
        {
            gl.Color(0f, 0f, 0f, 0);
            gl.PointSize(7f);
            gl.Begin(OpenGL.GL_POINTS);
            gl.Vertex(p.X, gl.RenderContextProvider.Height - p.Y);
            gl.End();
            gl.Flush();

            Color c = new Color();
            c = Color.White;
            Rectangle rec = new Rectangle(null, new Point(p.X - 3, p.Y - 3), new Point(p.X + 3, p.Y + 3), 1f, c, c, false,"");
            rec.showShape(gl);
        }

        public void DrawListPoint(List<Point> points, OpenGL gl)
        {
            gl.Color(color.R / 255.0, color.G / 255.0, color.B / 255.0);
            gl.PointSize(thickness);
            gl.Begin(OpenGL.GL_POINTS);
            for (int i = 0; i < points.Count(); i += 1)
            {
                gl.Vertex(points[i].X, gl.RenderContextProvider.Height - points[i].Y);
            }
            gl.End();
            gl.Flush();// Thực hiện lệnh vẽ ngay lập tức thay vì đợi sau 1 khoảng thời gian
        }

        public void DrawLine(Point Start, Point End, OpenGL gl) // vẽ đoạn thẳng
        {
            int dx = End.X - Start.X;
            int dy = End.Y - Start.Y;
            int stepX, stepY;
            Point temp = new Point(Start.X, Start.Y);
            List_Points.Add(temp);


            //xét dấu dx,dy
            if (dx < 0)
            {
                dx *= -1;
                stepX = -1;
            }
            else
            {
                stepX = 1;
            }
            if (dy < 0)
            {
                dy *= -1;
                stepY = -1;
            }
            else
            {
                stepY = 1;
            }

            // vẽ tập điểm của đoạn thẳng với pt y = ax + b
            if (dx > dy)  //nếu |a| < 1
            {
                int p = 2 * dy - 2 * dx;
                while (temp.X != End.X)
                {
                    if (p < 0)
                    {
                        p += 2 * dy;
                    }
                    else
                    {
                        temp.Y += stepY;
                        p += 2 * dy - 2 * dx;
                    }
                    temp.X += stepX;
                    List_Points.Add(temp);
                }

            }
            else // nếu |a| > 1
            {
                int p = 2 * dx - 2 * dy;
                while (temp.Y != End.Y)
                {
                    if (p < 0)
                    {
                        p += 2 * dx;
                    }
                    else
                    {
                        temp.X += stepX;
                        p += 2 * dx - 2 * dy;
                    }
                    temp.Y += stepY;
                    List_Points.Add(temp);
                }
            }

            DrawListPoint(List_Points, gl);  // Vẽ đoạn thẳng
        }

        public bool isInShape(Point cur) // kiểm tra điểm nằm trong hình?
        {
            //nếu current point nằm ngoài shape return false
            if (!List_Points.Exists(c => c.Y > cur.Y && c.X == cur.X) || !List_Points.Exists(c => c.Y < cur.Y && c.X == cur.X))
            {
                return false;
            }
            if (!List_Points.Exists(c => c.X > cur.X && c.Y == cur.Y) || !List_Points.Exists(c => c.X < cur.X && c.Y == cur.Y))
            {
                return false;
            }
            return true; //current point nằm trong shape
        }
        
        public virtual bool isOnShape(Point cur) // kiểm tra điểm có nằm trên cạnh của hình
        {
            Point current = new Point(cur.X, cur.Y);
            if (isCtrlPoint(cur) != -1)
            {
                return false;
            }
            return List_Points.Contains(current);
        }

        public int isCtrlPoint(Point cur) // trả về i nếu thành công, ngược lại trả về -1
        {
            int n = Ctrl_Points.Count();
            for (int i = 0; i < n; i++)
            {
                if (Math.Abs(Ctrl_Points[i].X - cur.X) < 5 && Math.Abs(Ctrl_Points[i].Y - cur.Y) < 5)
                {
                    return i;
                }
            }
            return -1;
        }

        public List<Point> getVertices()
        {
            if (vertices == null)
            {
                return new List<Point>();
            }
            else
            {
                return new List<Point>(vertices);
            }
        }

        public void setVertices(List<Point> vertices)
        {
            this.vertices = new List<Point>(vertices);
        }

        public List<Point> getPoints()
        {
            if (List_Points == null)
            {
                return new List<Point>();
            }
            else
            {
                return new List<Point>(List_Points);
            }
        }

        public List<Point> getCtrlPoints()
        {
            if (Ctrl_Points == null)
            {
                return new List<Point>();
            }
            else
            {
                return new List<Point>(Ctrl_Points);
            }
        }

        public float getThick()
        {
            return thickness;
        }

        public Color GetColor()
        {
            return color;
        }

        public Color getFillColor()
        {
            return FillColor;
        }

        public Boolean getFillVal()
        {
            return isFill;
        }

        public virtual Point getCenter()  // trả về tâm của hình
        {
            return new Point();
        }

        public virtual int getShapeType() // trả về dạng của hình
        {
            return 0;
        }
    }
}
