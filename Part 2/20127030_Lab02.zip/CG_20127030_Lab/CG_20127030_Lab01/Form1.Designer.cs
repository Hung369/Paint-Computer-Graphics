﻿namespace CG_20127030_Lab01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlDraw = new System.Windows.Forms.Panel();
            this.cbThickness = new System.Windows.Forms.ComboBox();
            this.lblThickness = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.tbClock = new System.Windows.Forms.TextBox();
            this.pb_Color = new System.Windows.Forms.PictureBox();
            this.pb_FillColor = new System.Windows.Forms.PictureBox();
            this.btnSquare = new System.Windows.Forms.Button();
            this.btnFill = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnRotate = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnPolygon = new System.Windows.Forms.Button();
            this.btnFillColor = new System.Windows.Forms.Button();
            this.btnColor = new System.Windows.Forms.Button();
            this.btnHexagon = new System.Windows.Forms.Button();
            this.btnPentagon = new System.Windows.Forms.Button();
            this.btnEllipse = new System.Windows.Forms.Button();
            this.btnRectangle = new System.Windows.Forms.Button();
            this.btnCircle = new System.Windows.Forms.Button();
            this.btnLine = new System.Windows.Forms.Button();
            this.openGLControl1 = new SharpGL.OpenGLControl();
            this.lblFillMode = new System.Windows.Forms.Label();
            this.cboFillSolution = new System.Windows.Forms.ComboBox();
            this.pnlDraw.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Color)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_FillColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlDraw
            // 
            this.pnlDraw.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlDraw.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlDraw.Controls.Add(this.cboFillSolution);
            this.pnlDraw.Controls.Add(this.lblFillMode);
            this.pnlDraw.Controls.Add(this.cbThickness);
            this.pnlDraw.Controls.Add(this.lblThickness);
            this.pnlDraw.Controls.Add(this.lblTime);
            this.pnlDraw.Controls.Add(this.tbClock);
            this.pnlDraw.Controls.Add(this.pb_Color);
            this.pnlDraw.Controls.Add(this.pb_FillColor);
            this.pnlDraw.Controls.Add(this.btnSquare);
            this.pnlDraw.Controls.Add(this.btnFill);
            this.pnlDraw.Controls.Add(this.btnSelect);
            this.pnlDraw.Controls.Add(this.btnRotate);
            this.pnlDraw.Controls.Add(this.btnRemove);
            this.pnlDraw.Controls.Add(this.btnClear);
            this.pnlDraw.Controls.Add(this.btnPolygon);
            this.pnlDraw.Controls.Add(this.btnFillColor);
            this.pnlDraw.Controls.Add(this.btnColor);
            this.pnlDraw.Controls.Add(this.btnHexagon);
            this.pnlDraw.Controls.Add(this.btnPentagon);
            this.pnlDraw.Controls.Add(this.btnEllipse);
            this.pnlDraw.Controls.Add(this.btnRectangle);
            this.pnlDraw.Controls.Add(this.btnCircle);
            this.pnlDraw.Controls.Add(this.btnLine);
            this.pnlDraw.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlDraw.Location = new System.Drawing.Point(0, 0);
            this.pnlDraw.Name = "pnlDraw";
            this.pnlDraw.Size = new System.Drawing.Size(1702, 157);
            this.pnlDraw.TabIndex = 0;
            // 
            // cbThickness
            // 
            this.cbThickness.FormattingEnabled = true;
            this.cbThickness.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "14",
            "16"});
            this.cbThickness.Location = new System.Drawing.Point(1174, 116);
            this.cbThickness.Name = "cbThickness";
            this.cbThickness.Size = new System.Drawing.Size(101, 24);
            this.cbThickness.TabIndex = 20;
            this.cbThickness.SelectedIndexChanged += new System.EventHandler(this.cbThickness_SelectedIndexChanged);
            // 
            // lblThickness
            // 
            this.lblThickness.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThickness.Location = new System.Drawing.Point(1041, 112);
            this.lblThickness.Name = "lblThickness";
            this.lblThickness.Size = new System.Drawing.Size(116, 28);
            this.lblThickness.TabIndex = 19;
            this.lblThickness.Text = "Thickness";
            this.lblThickness.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTime
            // 
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(440, 100);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(100, 36);
            this.lblTime.TabIndex = 18;
            this.lblTime.Text = "Time";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbClock
            // 
            this.tbClock.Location = new System.Drawing.Point(555, 107);
            this.tbClock.Name = "tbClock";
            this.tbClock.ReadOnly = true;
            this.tbClock.Size = new System.Drawing.Size(160, 22);
            this.tbClock.TabIndex = 17;
            // 
            // pb_Color
            // 
            this.pb_Color.Location = new System.Drawing.Point(1465, 38);
            this.pb_Color.Name = "pb_Color";
            this.pb_Color.Size = new System.Drawing.Size(55, 50);
            this.pb_Color.TabIndex = 16;
            this.pb_Color.TabStop = false;
            // 
            // pb_FillColor
            // 
            this.pb_FillColor.Location = new System.Drawing.Point(1268, 38);
            this.pb_FillColor.Name = "pb_FillColor";
            this.pb_FillColor.Size = new System.Drawing.Size(55, 50);
            this.pb_FillColor.TabIndex = 15;
            this.pb_FillColor.TabStop = false;
            // 
            // btnSquare
            // 
            this.btnSquare.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSquare.Location = new System.Drawing.Point(318, 63);
            this.btnSquare.Name = "btnSquare";
            this.btnSquare.Size = new System.Drawing.Size(104, 47);
            this.btnSquare.TabIndex = 14;
            this.btnSquare.Text = "Square";
            this.btnSquare.UseVisualStyleBackColor = true;
            this.btnSquare.Click += new System.EventHandler(this.btnSquare_Click);
            // 
            // btnFill
            // 
            this.btnFill.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFill.Location = new System.Drawing.Point(1043, 21);
            this.btnFill.Name = "btnFill";
            this.btnFill.Size = new System.Drawing.Size(114, 80);
            this.btnFill.TabIndex = 13;
            this.btnFill.Text = "Fill Shape";
            this.btnFill.UseVisualStyleBackColor = true;
            this.btnFill.Click += new System.EventHandler(this.btnFill_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(926, 21);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(111, 80);
            this.btnSelect.TabIndex = 12;
            this.btnSelect.Text = "Sellect Shape";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnRotate
            // 
            this.btnRotate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRotate.Location = new System.Drawing.Point(809, 21);
            this.btnRotate.Name = "btnRotate";
            this.btnRotate.Size = new System.Drawing.Size(111, 80);
            this.btnRotate.TabIndex = 11;
            this.btnRotate.Text = "Shape Rotation";
            this.btnRotate.UseVisualStyleBackColor = true;
            this.btnRotate.Click += new System.EventHandler(this.btnRotate_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(595, 28);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(104, 66);
            this.btnRemove.TabIndex = 10;
            this.btnRemove.Text = "Remove Shape";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(485, 38);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(104, 47);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "Clear All";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnPolygon
            // 
            this.btnPolygon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPolygon.Location = new System.Drawing.Point(291, 12);
            this.btnPolygon.Name = "btnPolygon";
            this.btnPolygon.Size = new System.Drawing.Size(104, 47);
            this.btnPolygon.TabIndex = 8;
            this.btnPolygon.Text = "Polygon";
            this.btnPolygon.UseVisualStyleBackColor = true;
            this.btnPolygon.Click += new System.EventHandler(this.btnPolygon_Click);
            // 
            // btnFillColor
            // 
            this.btnFillColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFillColor.Location = new System.Drawing.Point(1329, 21);
            this.btnFillColor.Name = "btnFillColor";
            this.btnFillColor.Size = new System.Drawing.Size(118, 80);
            this.btnFillColor.TabIndex = 7;
            this.btnFillColor.Text = "Fill Color";
            this.btnFillColor.UseVisualStyleBackColor = true;
            this.btnFillColor.Click += new System.EventHandler(this.btnFillColor_Click);
            // 
            // btnColor
            // 
            this.btnColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColor.Location = new System.Drawing.Point(1526, 19);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(109, 80);
            this.btnColor.TabIndex = 6;
            this.btnColor.Text = "Color";
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnHexagon
            // 
            this.btnHexagon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHexagon.Location = new System.Drawing.Point(212, 68);
            this.btnHexagon.Name = "btnHexagon";
            this.btnHexagon.Size = new System.Drawing.Size(100, 42);
            this.btnHexagon.TabIndex = 5;
            this.btnHexagon.Text = "Hexagon";
            this.btnHexagon.UseVisualStyleBackColor = true;
            this.btnHexagon.Click += new System.EventHandler(this.btnHexagon_Click);
            // 
            // btnPentagon
            // 
            this.btnPentagon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPentagon.Location = new System.Drawing.Point(181, 12);
            this.btnPentagon.Name = "btnPentagon";
            this.btnPentagon.Size = new System.Drawing.Size(104, 47);
            this.btnPentagon.TabIndex = 4;
            this.btnPentagon.Text = "Pentagon";
            this.btnPentagon.UseVisualStyleBackColor = true;
            this.btnPentagon.Click += new System.EventHandler(this.btnPentagon_Click);
            // 
            // btnEllipse
            // 
            this.btnEllipse.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEllipse.Location = new System.Drawing.Point(123, 68);
            this.btnEllipse.Name = "btnEllipse";
            this.btnEllipse.Size = new System.Drawing.Size(83, 42);
            this.btnEllipse.TabIndex = 3;
            this.btnEllipse.Text = "Ellipse";
            this.btnEllipse.UseVisualStyleBackColor = true;
            this.btnEllipse.Click += new System.EventHandler(this.btnEllipse_Click);
            // 
            // btnRectangle
            // 
            this.btnRectangle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRectangle.Location = new System.Drawing.Point(3, 68);
            this.btnRectangle.Name = "btnRectangle";
            this.btnRectangle.Size = new System.Drawing.Size(114, 42);
            this.btnRectangle.TabIndex = 2;
            this.btnRectangle.Text = "Rectangle";
            this.btnRectangle.UseVisualStyleBackColor = true;
            this.btnRectangle.Click += new System.EventHandler(this.btnRectangle_Click);
            // 
            // btnCircle
            // 
            this.btnCircle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCircle.Location = new System.Drawing.Point(92, 12);
            this.btnCircle.Name = "btnCircle";
            this.btnCircle.Size = new System.Drawing.Size(83, 47);
            this.btnCircle.TabIndex = 1;
            this.btnCircle.Text = "Circle";
            this.btnCircle.UseVisualStyleBackColor = true;
            this.btnCircle.Click += new System.EventHandler(this.btnCircle_Click);
            // 
            // btnLine
            // 
            this.btnLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLine.Location = new System.Drawing.Point(3, 12);
            this.btnLine.Name = "btnLine";
            this.btnLine.Size = new System.Drawing.Size(83, 47);
            this.btnLine.TabIndex = 0;
            this.btnLine.Text = "Line";
            this.btnLine.UseVisualStyleBackColor = true;
            this.btnLine.Click += new System.EventHandler(this.btnLine_Click);
            // 
            // openGLControl1
            // 
            this.openGLControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.openGLControl1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.openGLControl1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.openGLControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.openGLControl1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.openGLControl1.DrawFPS = false;
            this.openGLControl1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.openGLControl1.Location = new System.Drawing.Point(0, 164);
            this.openGLControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.openGLControl1.Name = "openGLControl1";
            this.openGLControl1.OpenGLVersion = SharpGL.Version.OpenGLVersion.OpenGL2_1;
            this.openGLControl1.RenderContextType = SharpGL.RenderContextType.FBO;
            this.openGLControl1.RenderTrigger = SharpGL.RenderTrigger.TimerBased;
            this.openGLControl1.Size = new System.Drawing.Size(1702, 842);
            this.openGLControl1.TabIndex = 0;
            this.openGLControl1.OpenGLInitialized += new System.EventHandler(this.openGLControl1_OpenGLInitialized);
            this.openGLControl1.OpenGLDraw += new SharpGL.RenderEventHandler(this.openGLControl1_OpenGLDraw);
            this.openGLControl1.Resized += new System.EventHandler(this.openGLControl1_Resized);
            this.openGLControl1.Load += new System.EventHandler(this.openGLControl1_Load);
            this.openGLControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseClick);
            this.openGLControl1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseDown);
            this.openGLControl1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseMove);
            this.openGLControl1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseUp);
            // 
            // lblFillMode
            // 
            this.lblFillMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFillMode.Location = new System.Drawing.Point(1329, 112);
            this.lblFillMode.Name = "lblFillMode";
            this.lblFillMode.Size = new System.Drawing.Size(169, 28);
            this.lblFillMode.TabIndex = 21;
            this.lblFillMode.Text = "Filling Solution";
            this.lblFillMode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cboFillSolution
            // 
            this.cboFillSolution.FormattingEnabled = true;
            this.cboFillSolution.Items.AddRange(new object[] {
            "scan",
            "flood"});
            this.cboFillSolution.Location = new System.Drawing.Point(1487, 116);
            this.cboFillSolution.Name = "cboFillSolution";
            this.cboFillSolution.Size = new System.Drawing.Size(110, 24);
            this.cboFillSolution.TabIndex = 22;
            this.cboFillSolution.SelectedIndexChanged += new System.EventHandler(this.cboFillSolution_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(1702, 1007);
            this.Controls.Add(this.openGLControl1);
            this.Controls.Add(this.pnlDraw);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Paint";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlDraw.ResumeLayout(false);
            this.pnlDraw.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Color)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_FillColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlDraw;
        private System.Windows.Forms.Button btnLine;
        private SharpGL.OpenGLControl openGLControl1;
        private System.Windows.Forms.Button btnRectangle;
        private System.Windows.Forms.Button btnCircle;
        private System.Windows.Forms.Button btnEllipse;
        private System.Windows.Forms.Button btnPentagon;
        private System.Windows.Forms.Button btnHexagon;
        private System.Windows.Forms.Button btnColor;
        private System.Windows.Forms.Button btnFillColor;
        private System.Windows.Forms.Button btnPolygon;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnRotate;
        private System.Windows.Forms.Button btnFill;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnSquare;
        private System.Windows.Forms.PictureBox pb_Color;
        private System.Windows.Forms.PictureBox pb_FillColor;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.TextBox tbClock;
        private System.Windows.Forms.Label lblThickness;
        private System.Windows.Forms.ComboBox cbThickness;
        private System.Windows.Forms.ComboBox cboFillSolution;
        private System.Windows.Forms.Label lblFillMode;
    }
}

