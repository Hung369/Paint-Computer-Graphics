﻿using SharpGL.SceneGraph.Primitives;
using SharpGL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CG_20127030_Lab01
{
    class Painter
    {
        public Color colorUserColor; //màu để vẽ hình

        public int shShape;   // 0 là đường thẳng,
                              // 1 là đường tròn,
                              // 2 là hình ellipse,
                              // 3 là hình chữ nhật,
                              // 4 là hình vuông,
                              // 5 là ngũ giác đều,
                              // 6 là lục giác đều,
                              // 7 là đa giác

        public int old; // lưu lại loại hình đang vẽ khi edit
        public Point pStart, pEnd;
        public bool isDrawing;     //check đang vẽ hay không
        public bool isDrawDone;    //check vẽ xong hay chưa
        public bool isEdit;        //check đang chỉnh sửa hay không
        public bool isFree;        //check đang ở chế độ nào không
        public float thick;  //độ dày của nét
        public bool isClear;  // yêu cầu xóa framebuffer
        public bool isRemove;   // yêu cầu hoàn tác
        public bool isSelect; // chọn shape
        public int indexEdit; // loại hình được chọn để chỉnh sửa, mặc định bằng -1
        public double timeSpan;

        public Color color_fill; //màu tô        
        public bool isFill; //chế độ tô màu
        public string fill_mode; // loại tô màu - "scan": tô quét, "flood": tô loang.
        
        public List<Shape> shapes; // buffer hình        
        public Shape shape; // hình đang được thao tác hiện tại

       
        public Stopwatch stopwatch;  // công cụ đo thời gian

                
        public List<Point> vertices; // danh sách các đỉnh 
        public int nVertices; // số đỉnh đa giác

        public List<Point> vertices_transform; // đỉnh sau khi biến đổi 

        
        public List<Point> points; // danh sách các điểm thuộc hình

        public List<Point> points_transform; // các điểm thuộc hình sau biến đổi

        public List<Point> controlPoints; // danh sách các điểm điều khiển

        public List<Point> controlPoints_transform; // các điểm điều khiển sau khi biến đổi
 
        public Point oldPos;
        
        public bool isTranslate; // check translation
        
        public bool isScale; // check scale shape
        
        public bool isRotate; // check  rotation
        
        public bool isMove1CtrlPoint; //check dịch chuyển 1 điểm điều khiển, đối với đoạn thẳng và đa giác
        //trong tâm của hình
        Point Center;
        
        public int indexCtrlPoint;

        // cờ báo hiệu mouseDown -> để thực hiện thao tác rotate khi edit
        public bool isDown;
        public Painter()
        {
            colorUserColor = Color.White; // màu mặc định là màu trắng, vì nền đen
            
            color_fill = Color.Red; // màu tô mặc định là màu đỏ
            
            shShape = 0; //mặc định vẽ đoạn thẳng

            isDrawing = false;
            isDrawDone = false;
            isEdit = false;
            isFree = true;

            thick = 1f; // mặc định = 1.0
            shapes = new List<Shape>();
            shape = null;

            isClear = false;
            isRemove = false;
            isSelect = false;
            indexEdit = -1;

            stopwatch = new Stopwatch();
            timeSpan = 0;
            isFill = false;
            fill_mode = "scan";

            vertices = new List<Point>();
            nVertices = 0;
            points = new List<Point>();
            controlPoints = new List<Point>();

            isDown = false;
            isMove1CtrlPoint = false;
        }

        // vẽ danh sách đối tượng hình
        public void ShowListShapes(OpenGL gl)
        {
            int n = shapes.Count();
            for (int i = 0; i < n; i++)
            {
                shapes[i].showShape(gl);
            }
        }

        // nếu user clear màn hình ->  reset các giá trị về giá trị mặc định
        public void handleClear()
        {
            if (isClear)
            {
                if (isEdit)
                {
                    shape = null;
                    isEdit = false;
                    isFree = true;
                }
                shapes.Clear();
                isClear = false;
                indexEdit = -1;
                if (vertices.Count() != 0)
                {
                    vertices.Clear();
                }
                nVertices = 0;
            }
        }

        public void handleRemove()
        {
            if (isRemove)
            {
                if (isFree) // Nếu người dùng yêu cầu xóa hình đã chọn hay hình vẽ cuối cùng
                {
                    if (shapes.Count() > 0)
                    {
                        shapes.RemoveAt(shapes.Count() - 1);
                    }
                }
                if (isEdit)
                {
                    if (indexEdit != -1)
                    {
                        shapes.RemoveAt(indexEdit);
                        indexEdit = -1;
                    }
                    shape = null;
                    isEdit = false;
                    isFree = true;
                }
                isRemove = false;
                if (vertices.Count() != 0)
                {
                    vertices.Clear();
                }
                nVertices = 0;
            }
        }
        public void createShape() // nếu đang thao tác trên shape -> cập nhật shape
        {
            if (shShape == 0)
            {
                shape = new Line(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill);
            }
            else if (shShape == 1)
            {
                shape = new Circle(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (shShape == 3)
            {
                shape = new Rectangle(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (shShape == 2)
            {
                shape = new Ellipse(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (shShape == 4)
            {
                shape = new Square(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (shShape == 5)
            {
                shape = new Pentagon(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (shShape == 6)
            {
                shape = new Hexagon(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
            else if (shShape == 7)
            {
                shape = new Polygon(vertices, pStart, pEnd, thick, colorUserColor, color_fill, isFill, fill_mode);
            }
        }

        public void handleDrawing(OpenGL gl)
        {
            //vẽ và đo thời gian khi vẽ
            createShape();
            stopwatch.Start();
            shape.showShape(gl);
            stopwatch.Stop();

            // tính thời gian vẽ
            timeSpan = stopwatch.Elapsed.TotalMilliseconds * 1000;
            timeSpan /= 1000;
            getProperties(shape);
        }
        public void handleEdit(OpenGL gl)
        {
            shape.editShape(vertices_transform, points_transform, controlPoints_transform, thick, colorUserColor, color_fill, isFill);
            shape.ShowEditShape(gl);
        }

        public void handleDrawDone()
        {
            if (indexEdit == -1)
            {
                shapes.Add(shape);
                shape = null;
            }
            else indexEdit = -1;
            // reset vertices
            if (vertices.Count() != 0)
            {
                vertices.Clear();
            }
            nVertices = 0;

            isDrawDone = false;
            isFree = true;
        }

        // xử lí các thao tác người dùng
        public void HandlePaint(OpenGL gl)
        {
            if (isDrawing || isEdit || isDrawDone)
            {
                if (shape != null && isDrawing == false)
                {
                    shape.showShape(gl);
                }
                if (isDrawing)
                    handleDrawing(gl);
                if (isEdit)
                    handleEdit(gl);
                if (isDrawDone)
                    handleDrawDone();

                stopwatch.Reset();
            }
        }

        public void getProperties(Shape sh)
        {
            vertices = sh.getVertices();
            vertices_transform = sh.getVertices();

            points = sh.getPoints();
            points_transform = sh.getPoints();

            controlPoints = sh.getCtrlPoints();
            controlPoints_transform = sh.getCtrlPoints();

            thick = sh.getThick();
            colorUserColor = sh.GetColor();
            color_fill = sh.getFillColor();
            isFill = sh.getFillVal();

            Center = shape.getCenter();
            old = shShape;
            shShape = sh.getShapeType();
        }

        public void turnOffActiveMode()
        {
            if (isDrawing || isEdit)
            {
                isDrawDone = true;
                isDrawing = false;
                isEdit = false;
            }

            if (isSelect)
            {
                isSelect = false;
            }
        }
       
    }
}
