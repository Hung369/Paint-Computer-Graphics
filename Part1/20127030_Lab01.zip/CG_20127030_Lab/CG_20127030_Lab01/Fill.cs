﻿using SharpGL.SceneGraph;
using SharpGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace CG_20127030_Lab01
{
    class Fill
    {
        bool IsSameColor(RGB first, RGB second) // kiểm tra cùng màu
        {
            if (first.red == second.red && first.green == second.green && first.blue == second.blue)
                return true;
            return false;
        }
        RGB GetPixel(int x, int y, OpenGL gl)
        {
            byte[] pixelData = new byte[3];
            gl.ReadPixels(x, y, 1, 1, OpenGL.GL_RGB, OpenGL.GL_BYTE, pixelData);

            RGB color = new RGB(pixelData);

            return color;
        }

        void ColoringPixel(int x, int y, Color color, OpenGL gl)
        {
            byte[] ptr = new byte[3];
            ptr[0] = color.R;
            ptr[1] = color.G;
            ptr[2] = color.B;
            gl.RasterPos(x, y);
            gl.DrawPixels(1, 1, OpenGL.GL_RGB, ptr);
            gl.Flush();
        }
        public void Floodfill(int x, int y, Color fill_color, Color Boundary_color, OpenGL gl) // tô loang
        {
            RGB Fill_Color = new RGB(fill_color);
            RGB Pix_Color = GetPixel(x, y, gl);
            RGB border = new RGB(Boundary_color);

            Queue<Point> q = new Queue<Point>();
                       
            
            
            if (IsSameColor(Fill_Color, Pix_Color)) // nếu màu điểm sắp tô giống màu tô thì dừng
                return;

            q.Enqueue(new Point(x, y));

            while (q.Count() != 0) // dùng queue để lưu màu tô, thuật toán BFS.
            {
                Point p;
                p = q.Dequeue();

                RGB currentColor = GetPixel(p.X, p.Y, gl);
                if (IsSameColor(currentColor, border) || IsSameColor(currentColor, Fill_Color))
                    return ;

                ColoringPixel(p.X, p.Y, fill_color, gl);
                q.Enqueue(new Point(p.X + 1, p.Y));
                q.Enqueue(new Point(p.X - 1, p.Y));
                q.Enqueue(new Point(p.X, p.Y + 1));
                q.Enqueue(new Point(p.X, p.Y - 1));
            }
        }

        public void ScanFill(List<Point> vertices, Color fill_color, OpenGL gl) // tô quét
        {
            int nVertices = vertices.Count();
            if (nVertices < 3)
            {
                return;
            }

            List<Edge> edges = new List<Edge>();
            List<AEL> aels = new List<AEL>();


            int height = gl.RenderContextProvider.Height;

            for (int i = 0; i < nVertices; i++)
            {
                Point Lower = new Point();
                Point Upper = new Point();
                float reci_slope;
                Point prev, cur, next_p, after_next;

                cur = vertices[i];

                if (i == 0) // nếu là đỉnh đầu tiên thì đỉnh trước nó là đỉnh cuối cùng
                {
                    prev = vertices[nVertices - 1];
                }
                else 
                { 
                    prev = vertices[i - 1]; 
                }


                if (i == nVertices - 1) // nếu đỉnh đang xét là đỉnh cuối cùng thì đỉnh sau nó là đỉnh cuối cùng
                {
                    next_p = vertices[0];
                }
                else 
                { 
                    next_p = vertices[i + 1]; 
                }

                if (i + 2 > nVertices - 1) // nếu đỉnh kế của next là đỉnh cuối
                {
                    after_next = vertices[i + 2 - nVertices];
                }
                else 
                { 
                    after_next = vertices[i + 2]; 
                }

                
                if (cur.Y == next_p.Y) //xét cạnh Pcur - Pnext_p nếu song song với Ox thì bỏ qua cạnh này
                {
                    continue;
                }

                if (cur.Y > next_p.Y)
                {
                    Upper.X = cur.X;
                    Upper.Y = cur.Y;

                    Lower.X = next_p.X;
                    Lower.Y = next_p.Y;

                   
                    if (cur.Y <= prev.Y)  // kiểm tra đỉnh cực trị
                    {
                        
                        Upper.Y -= 1; // làm ngắn cạnh để tạo điểm ảo.
                    }
                }
                else
                {
                    Upper.X = next_p.X;
                    Upper.Y = next_p.Y;

                    Lower.X = cur.X;
                    Lower.Y = cur.Y;

                    
                    if (next_p.Y <= after_next.Y) // check điều kiện của đỉnh cực trị
                    {
                        Upper.Y -= 1;
                    }
                }
                reci_slope = (Upper.X - Lower.X) * 1f / (Upper.Y - Lower.Y); // nghịch đảo độ dốc

                edges.Add(new Edge(Lower, Upper));
                aels.Add(new AEL(Upper.Y, Lower.X, reci_slope));
            }


            // xác định Y_min,Y_max
            int y_min = int.MaxValue;
            int y_max = int.MinValue;
            for (int i = 0; i < nVertices; i++)
            {
                if (y_min > vertices[i].Y)
                {
                    y_min = vertices[i].Y;
                }
                if (y_max < vertices[i].Y)
                {
                    y_max = vertices[i].Y;
                }
            }

            // tạo bảng ET (Edge Table)
            List<List<AEL>> ET = new List<List<AEL>>();
            for (int i = 0; i < y_max - y_min; i++)
            {
                List<AEL> a = new List<AEL>();
                ET.Add(a);
            }

            // index 0 trong ET ứng với y = y_min
            int k = 0;
            int nEdges = edges.Count();
            for (int y = y_min; y < y_max; y++)
            {
                for (int i = 0; i < nEdges; i++)
                {
                    // nếu y_lower của cạnh bằng y dòng 
                    if (edges[i].Lower_Point.Y == y)
                    {
                        ET[k].Add(new AEL(aels[i]));
                    }
                }
                k++;
            }



            List<AEL> beglist = new List<AEL>();
            k = 0;
            
            for (int y = y_min; y < y_max; y++) // thực hiện quá trình tô quét
            {
                if (ET[k].Count() != 0)
                {
                    for (int i = 0; i < ET[k].Count(); i++)
                    {
                        beglist.Add(ET[k][i]);
                    }
                }
                if (beglist.Count() != 0)
                {
                    // khởi tạo các giá trị hoành độ trong beglist vào mảng mới
                    List<float> x_list = new List<float>();
                    for (int i = 0; i < beglist.Count(); i++)
                    {
                        x_list.Add(beglist[i].x_int);
                    }
                    
                    x_list.Sort(); // sắp xếp theo thứ tự tăng dần

                    if (x_list.Count() % 2 == 0) // tô màu theo cặp giao điểm chẵn lẻ
                    {
                        for (int i = 0; i < x_list.Count(); i += 2)
                        {
                            Point st = new Point((int)Math.Round(x_list[i]), y);
                            Point end = new Point((int)Math.Round(x_list[i + 1]), y);

                            gl.Color(fill_color.R / 255.0, fill_color.G / 255.0, fill_color.B / 255.0);
                            gl.Begin(OpenGL.GL_LINES);
                            gl.Vertex(st.X, gl.RenderContextProvider.Height - st.Y);
                            gl.Vertex(end.X, gl.RenderContextProvider.Height - end.Y);
                            gl.End();
                        }
                    }

                    // loại bỏ cạnh có y = y_upper và cập nhật giá trị x_int
                    for (int i = 0; i < beglist.Count(); i++)
                    {
                        if (beglist[i].y_upper == y) // nếu y_upper = y thì xóa khỏi beglist
                        {
                            beglist.Remove(beglist[i]);
                            i--;
                        }
                        else // nếu không thì tăng x_int
                        {
                            beglist[i].x_int += beglist[i].reci_slope;
                        }
                    }
                }
                k++;
            }
        }

    }

    struct RGB // Màu RGB
    {
        public byte red, green, blue;
        public RGB(Color color)
        {
            this.red = color.R;
            this.green = color.G;
            this.blue = color.B;
        }
        public RGB(byte[] color)
        {
            this.red = color[0];
            this.green = color[1];
            this.blue = color[2];
        }
    }

    struct Edge // lưu điểm đầu và cuối của cạnh
    {
        public Point Lower_Point, Upper_Point;
        public Edge(Point Lower, Point Upper)
        {
            Lower_Point = Lower;
            Upper_Point = Upper;
        }
    }

    class AEL // active edge list pointer
    {
        public int y_upper;
        public float x_int, reci_slope;
        public AEL next;

        public AEL(AEL a)
        {
            y_upper = a.y_upper;
            x_int = a.x_int;
            reci_slope = a.reci_slope;
            next = a.next;
        }
        public AEL(int y_upper, float x_int, float reci_slope, AEL next = null)
        {
            // giao điểm giữa đường quét và cạnh
            this.y_upper = y_upper;
            this.x_int = x_int;

           
            this.reci_slope = reci_slope; // nghịch đảo độ dốc
            this.next = next;
        }
    }
}
