﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using SharpGL;
using System.Reflection;

namespace CG_20127030_Lab01
{
    public partial class Form1 : Form
    {
        Painter paint;
        public Form1()
        {
            InitializeComponent();
            paint = new Painter();
            pb_Color.BackColor = paint.colorUserColor;
            pb_FillColor.BackColor = paint.color_fill;
        }

        private void openGLControl1_OpenGLDraw(object sender, SharpGL.RenderEventArgs args)
        {
            // Get the OpenGL object.
            OpenGL gl = openGLControl1.OpenGL;

            // Clear the color and depth buffer.
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

            //nếu user yêu cầu làm mới 
            paint.handleClear();

            //nếu user yêu cầu xóa
            paint.handleRemove();

            //Vẽ list Shape
            paint.ShowListShapes(gl);


            Stopwatch stopwatch = new Stopwatch();
            // xử lí yêu cầu vẽ
            paint.HandlePaint(gl);
        }

        private void openGLControl1_OpenGLInitialized(object sender, EventArgs e)
        {
            // Get the OpenGL object.
            OpenGL gl = openGLControl1.OpenGL;
            // Set the clear color.
            gl.ClearColor(0, 0, 0, 0);
            // Set the projection matrix.
            gl.MatrixMode(OpenGL.GL_PROJECTION);
            // Load the identity.
            gl.LoadIdentity();

        }

        private void openGLControl1_Resized(object sender, EventArgs e)
        {
            // Get the OpenGL object.
            OpenGL gl = openGLControl1.OpenGL;
            // Set the projection matrix.
            gl.MatrixMode(OpenGL.GL_PROJECTION);
            // Load the identity.
            gl.LoadIdentity();
            // Create a perspective transformation.
            gl.Viewport(0, 0, openGLControl1.Width, openGLControl1.Height);
            gl.Ortho2D(0, openGLControl1.Width, 0, openGLControl1.Height);
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog(); //Khởi tạo đối tượng ColorDialog 

            //Nếu người dùng chọn xong và bấm OK
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                paint.colorUserColor = dlg.Color;
                pb_Color.BackColor = paint.colorUserColor;
            }
        }

        private void btnFillColor_Click(object sender, EventArgs e)
        {
            ColorDialog dlgF = new ColorDialog(); // Khởi tạo đối tượng ColorDialog 

            // Nếu người dùng chọn xong và bấm OK
            if (dlgF.ShowDialog() == DialogResult.OK)
            {
                paint.color_fill = dlgF.Color;
                pb_FillColor.BackColor = paint.color_fill;
            }
        }

        private void openGLControl1_Load(object sender, EventArgs e)
        {

        }

        private void openGLControl1_MouseClick(object sender, MouseEventArgs e)
        {
            if (paint.shShape == 7)
            {
                if (e.Button == MouseButtons.Left)
                {
                    if (paint.isDrawing) // nếu đang vẽ
                    {
                        Point v = new Point(e.Location.X, e.Location.Y);
                        paint.vertices.Add(v);
                        paint.nVertices++;
                    }
                }
                if (e.Button == MouseButtons.Right)
                {
                    if (paint.isDrawing)
                    {
                        //nếu đa giác có 3 đỉnh trở lên -> nVertices = 2 thì ở thời gian thực đa giác có 3 đỉnh
                        if (paint.nVertices > 1)
                        {
                            //nếu không vẽ nữa thì chuyển sang chế độ edit
                            paint.isDrawing = false;
                            paint.isEdit = true;
                            //xử lí khi 2 điểm cuối cùng là 1 điểm
                            if (paint.nVertices != 0 && paint.nVertices == paint.vertices.Count() - 1 
                                && paint.vertices[paint.nVertices].Equals(paint.vertices[paint.nVertices - 1]))
                            {
                                paint.vertices.RemoveAt(paint.nVertices);
                                paint.shape.setVertices(paint.vertices);
                            }
                        }
                    }
                }

            }
        }

        private void openGLControl1_MouseDown(object sender, MouseEventArgs e)
        {
            if (paint.isSelect)
            {
                bool Out_of_box = true; // kiểm tra nếu ở chế độ select và nhấp chuôt ngoài hình
                Point current = e.Location;
                int maxIndex = paint.shapes.Count() - 1;
                for (int i = maxIndex; i > -1; i--)
                {
                    if (paint.shapes[i].isInShape(current) || paint.shapes[i].isOnShape(current))
                    {
                        paint.shape = paint.shapes[i];
                        paint.getProperties(paint.shape);
                        paint.indexEdit = i;
                        
                        paint.isEdit = true; // bật chế độ edit và tắt chế độ rảnh
                        paint.isFree = false;

                        Out_of_box = false;
                        paint.isSelect = false;
                        break;
                    }
                }
                if (Out_of_box)
                {
                    return;
                }
            }
            
            if (paint.isFree) // kiểm tra nếu bắt đầu vẽ thì bật cờ isDrawing
            {
                if (paint.shShape != 7)
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        paint.pStart = e.Location;
                        paint.pEnd = paint.pStart;
                        paint.isDrawing = true;
                        paint.isFree = false;
                    }
                }
                else
                {
                    
                    paint.isDrawing = true; // bật isDrawing
                    paint.isFree = false;
                }
            }
            if (paint.isEdit)
            {
                Point current = e.Location;

                if (paint.shape.isCtrlPoint(current) != -1)
                {
                    paint.indexCtrlPoint = paint.shape.isCtrlPoint(current);
                    paint.oldPos = current;
                    if (!paint.isRotate) // nếu chế độ rotate tắt thì bật scale
                    {
                        if ((paint.shShape == 0 || paint.shShape == 7) && e.Button == MouseButtons.Right)
                        {
                            paint.isMove1CtrlPoint = true;
                        }
                        else
                        {
                            paint.isScale = true;
                        }
                    }
                    else
                    {
                        // bật điểm điều khiển
                        paint.isDown = true;
                    }

                }
                else if (!paint.shape.isInShape(current) && !paint.shape.isOnShape(current))
                {
                    // nếu click chuột ngoài shape thì dừng edit và lưu
                    paint.isEdit = false;
                    paint.isDrawDone = true;
                    paint.shShape = paint.old;
                }
                else if (paint.shShape == 0 && paint.shape.isOnShape(current))
                {
                    // nếu tịnh tiến đoạn thẳng
                    paint.oldPos = current;
                    paint.isTranslate = true;
                }
                else if (paint.shShape != 0 && paint.shape.isInShape(current))
                {
                    // nếu tịnh tiến các hình còn lại
                    paint.oldPos = current;
                    paint.isTranslate = true;
                }
            }
        }

        private void openGLControl1_MouseMove(object sender, MouseEventArgs e)
        {
            if (paint.isSelect)
            {
                //kiểm tra nếu ở chế độ select và nhấp chuôt ngoài hình
                bool Out_of_Box = true;
                Point current = e.Location;
                int maxIndex = paint.shapes.Count() - 1;
                for (int i = maxIndex; i > -1; i--)
                {
                    if (paint.shapes[i].isInShape(current) || paint.shapes[i].isOnShape(current))
                    {
                        openGLControl1.Cursor = Cursors.Hand;
                        Out_of_Box = false;
                        break;
                    }
                }
                if (Out_of_Box)
                {
                    openGLControl1.Cursor = Cursors.Default;
                }
            }

            //đang ở mode edit
            if (paint.isEdit)
            {
                Point current = new Point(e.Location.X, e.Location.Y);

                
                    //đoạn thẳng
                    if (paint.shShape == 0)
                    {
                        if (paint.shape.isOnShape(current))
                        {
                            openGLControl1.Cursor = Cursors.SizeAll;
                        }
                        else if (paint.shape.Ctrl_Points != null && paint.shape.isCtrlPoint(current) != -1)
                        {
                            openGLControl1.Cursor = Cursors.SizeNS;
                        }
                        else
                        {
                            openGLControl1.Cursor = Cursors.Default;
                        }
                    }
                    else if (paint.shShape == 7) // đa giác
                    {
                        if (paint.shape.isInShape(current) == true)
                        {
                            openGLControl1.Cursor = Cursors.SizeAll;
                        }
                        else if (paint.shape.Ctrl_Points != null && paint.shape.isCtrlPoint(current) != -1)
                        {
                            openGLControl1.Cursor = Cursors.SizeNS;
                        }
                        else
                        {
                            openGLControl1.Cursor = Cursors.Default;
                        }
                    }
                    else // hình còn lại
                    {
                        if (paint.shape.isInShape(current) == true)
                        {
                            openGLControl1.Cursor = Cursors.SizeAll;
                        }
                        else if (paint.shape.Ctrl_Points != null && paint.shape.isCtrlPoint(current) != -1)
                        {
                            int index = paint.shape.isCtrlPoint(current);
                            if (index == 0 || index == 4)
                            {
                                openGLControl1.Cursor = Cursors.SizeNWSE;
                            }
                            if (index == 1 || index == 5)
                            {
                                openGLControl1.Cursor = Cursors.SizeNS;
                            }
                            if (index == 2 || index == 6)
                            {
                                openGLControl1.Cursor = Cursors.SizeNESW;
                            }
                            if (index == 3 || index == 7)
                            {
                                openGLControl1.Cursor = Cursors.SizeWE;
                            }
                        }
                        else
                        {
                            openGLControl1.Cursor = Cursors.Default;
                        }
                    }
            }
  
            if (paint.isDrawing) // đang vẽ
            {
                //các hình cơ bản
                if (paint.shShape != 7)
                {
                    //cập nhật pEnd
                    paint.pEnd = e.Location;
                }
                //đa giác
                else
                {
                    //xóa các đỉểm khi vẽ ở thời gian thực
                    paint.vertices.RemoveRange(paint.nVertices, paint.vertices.Count() - paint.nVertices);
                    //thêm điểm tiếp theo
                    paint.vertices.Add(new Point(e.Location.X, e.Location.Y));
                }
            }
        }

        private void openGLControl1_MouseUp(object sender, MouseEventArgs e)
        {
            if (paint.shShape != 7)
            {
                String DrawingTime = String.Format("{0:0.000}", paint.timeSpan);
                tbClock.Text = DrawingTime + " ms";
                if (paint.isDrawing)
                {
                    paint.isDrawing = false;
                    paint.isEdit = true;
                }
            }
        }

        private void btnEllipse_Click(object sender, EventArgs e)
        {
            paint.turnOffActiveMode();
            paint.shShape = 2;
        }

        private void btnRectangle_Click(object sender, EventArgs e)
        {
            paint.turnOffActiveMode();
            paint.shShape = 3;
        }

        private void btnLine_Click(object sender, EventArgs e)
        {
            paint.turnOffActiveMode();
            paint.shShape = 0;
        }

        private void btnCircle_Click(object sender, EventArgs e)
        {
            paint.turnOffActiveMode();
            paint.shShape = 1;
        }

        private void btnSquare_Click(object sender, EventArgs e)
        {
            paint.turnOffActiveMode();
            paint.shShape = 4;
        }

        private void btnPentagon_Click(object sender, EventArgs e)
        {
            paint.turnOffActiveMode();
            paint.shShape = 5;
        }

        private void btnPolygon_Click(object sender, EventArgs e)
        {
            paint.turnOffActiveMode();
            paint.vertices.Clear();
            paint.nVertices = 0;
            paint.shShape = 7;
        }

        private void btnHexagon_Click(object sender, EventArgs e)
        {
            paint.turnOffActiveMode();
            paint.shShape = 6;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            paint.isClear = true;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            paint.isRemove = true;
        }

        private void btnRotate_Click(object sender, EventArgs e)
        {
            paint.isRotate = true;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (paint.isEdit)
            {
                paint.isDrawDone = true;
                paint.isDrawing = false;
                paint.isEdit = false;
            }
            paint.isSelect = true;
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            if (paint.isFill)
            {
                paint.isFill = false;
            }
            else
            {
                paint.isFill = true;
            }
        }

        private void cbThickness_SelectedIndexChanged(object sender, EventArgs e)
        {
            int thickness = int.Parse(cbThickness.Text);
            paint.thick = thickness;
        }

        private void cboFillSolution_SelectedIndexChanged(object sender, EventArgs e)
        {
            string result = cboFillSolution.Text;
            paint.fill_mode = result;
        }
    }
}
